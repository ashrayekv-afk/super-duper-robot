/* Integrated bilateral corneal viewer. Patient coordinates and source values
 * are supplied by integrated_model.js. Materials, camera and point selection
 * never deform those coordinates. No patient example data are bundled. */
(function(global){'use strict';
const EYES=['OD','OS'],FIELDS=['thickness','anterior','posterior','elevation','posterior_elevation'];
const LAYERS=[{id:'shape',label:'Natural eye',unit:''},{id:'anterior',label:'Anterior curvature',unit:'D'},
 {id:'posterior',label:'Posterior curvature |D|',unit:'D'},{id:'thickness',label:'Thickness',unit:'µm'},
 {id:'elevation',label:'Anterior elevation',unit:'µm'},{id:'posterior_elevation',label:'Posterior elevation',unit:'µm'}];
const LABELS=Object.fromEntries(LAYERS.map(x=>[x.id,x.label]));
const PI=Math.PI,finite=Number.isFinite,clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const add=(a,b)=>a.map((v,i)=>v+b[i]),sub=(a,b)=>a.map((v,i)=>v-b[i]),mul=(a,s)=>a.map(v=>v*s),dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],unit=a=>mul(a,1/(Math.hypot(...a)||1));
const median=a=>{const b=[...a].sort((x,y)=>x-y);return b.length?b[Math.floor(b.length/2)]:0;};
const coveragePercent=(n,total)=>{const value=total?100*n/total:0;return value>0&&value<.1?'<0.1%':value.toFixed(1)+'%';};
let serial=0;
function numeric(value,key,approx){if(!finite(value)||(key==='thickness'&&value<=0))return 'Unavailable';const prefix=approx?'≈ ':'';
 return prefix+(key==='anterior'||key==='posterior'?(key==='posterior'?Math.abs(value):value).toFixed(1)+' D':key==='thickness'?Math.round(value)+' µm':(value>=0?'+':'')+Math.round(value)+' µm');}
function wrap(ctx,text,width){const lines=[];let line='';for(const word of String(text).split(/\s+/)){const next=line?line+' '+word:word;if(line&&ctx.measureText(next).width>width){lines.push(line);line=word;}else line=next;}if(line)lines.push(line);return lines;}
function mount(host,setsByEye={},results={},options={}){
 if(!host)throw Error('A corneal viewer container is required.');
 const M=global.NKPIIntegratedMeasurements,C=global.NKPIIntegratedCoverage;
 if(!M||!C)throw Error('The corneal measurement and coverage display modules are unavailable.');
 const id='nkpi-integrated-'+(++serial),sets={},prepared=new Map(),views={},selection=new Map(),mapSelection=new Map();let dead=false;
 for(const eye of EYES){sets[eye]=(setsByEye[eye]||[]).filter(s=>s&&s.eye===eye&&['first','latest'].includes(s.visit));}
 const visits=new Set(EYES.flatMap(e=>sets[e].map(s=>s.visit))),initial=options.initialState||{};
 const state={visit:visits.has('latest')?'latest':'first',color:'shape',yaw:-.94,pitch:-.13,zoom:1,section:true,contours:true,estimates:true,mapView:false};
 for(const k of ['yaw','pitch','zoom'])if(finite(initial[k]))state[k]=initial[k];
 state.pitch=clamp(state.pitch,-1.25,1.25);state.zoom=clamp(state.zoom,.6,1.8);
 if(visits.has(initial.visit))state.visit=initial.visit;
 if(typeof initial.section==='boolean')state.section=initial.section;
 if(typeof initial.contours==='boolean')state.contours=initial.contours;
 if(typeof initial.estimates==='boolean')state.estimates=initial.estimates;
 if(typeof initial.mapView==='boolean')state.mapView=initial.mapView;
 if(LAYERS.some(l=>l.id===initial.color))state.color=initial.color;
 if(state.color==='shape')state.mapView=false;
 const root=document.createElement('section');root.className='nkpi-integrated-eye';root.id=id;root.setAttribute('aria-label','Integrated bilateral corneal figure');
 root.innerHTML='<div class="ie-window"><header class="ie-header"><div><span class="ie-eyebrow">INTEGRATED CORNEA</span><h2>Two eyes. One connected view.</h2></div><div class="ie-actions">'+(options.canCompare?'<button type="button" data-ie-change>Change maps ↓</button>':'')+'<button type="button" data-ie-save>Save both eyes</button></div></header>'+
 '<div class="ie-visits"><div class="ie-segment" role="group" aria-label="Scan visit">'+[['first','Baseline'],['latest','Latest']].map(([v,label])=>'<button type="button" data-ie-visit="'+v+'">'+label+'</button>').join('')+'</div><span class="ie-status" data-ie-status></span></div>'+
 '<div class="ie-toolbar"><div class="ie-segment" role="group" aria-label="Corneal display"><button type="button" data-ie-mode="whole">Whole surface</button><button type="button" data-ie-mode="section">Section</button></div><label class="ie-field">Color <select data-ie-field aria-label="Map tint on both corneas">'+LAYERS.map(l=>'<option value="'+l.id+'">'+l.label+'</option>').join('')+'</select></label><span class="ie-scale">Equal x/y/z scale</span></div>'+
 '<div class="ie-toolbar ie-actions" role="group" aria-label="Shared camera"><button type="button" data-ie-view="reset">3D</button><button type="button" data-ie-view="front">Front</button><button type="button" data-ie-view="profile">Profile</button><button type="button" data-ie-view="map">Map view</button><button type="button" data-ie-zoom="out" aria-label="Zoom both eyes out">−</button><button type="button" data-ie-zoom="in" aria-label="Zoom both eyes in">+</button><label class="ie-check ie-contour-toggle"><input type="checkbox" data-ie-contours checked>Contour lines</label><label class="ie-check ie-estimate-toggle" title="Estimate small enclosed or narrow report-color gaps only with direct support across the gap. Missing native values, uncertain colors and unsupported surface heights remain unavailable."><input type="checkbox" data-ie-estimates checked>Estimate narrow gaps</label></div>'+
 '<div class="ie-eyes">'+EYES.map(eye=>'<article class="ie-eye" data-ie-eye="'+eye+'"><header class="ie-eye-title"><strong>'+eye+' <span>'+(eye==='OD'?'Right':'Left')+' eye</span></strong><span data-coverage></span></header><div class="ie-source" data-ie-source></div><div class="ie-scene"><canvas class="ie-geometry" role="img" aria-label="'+eye+' corneal surface; drag to rotate both eyes"></canvas><canvas class="ie-overlay" aria-hidden="true"></canvas><div class="ie-empty" data-ie-empty hidden></div><span class="ie-location-label" data-ie-location-label></span></div><div class="ie-scale-label" data-ie-legend></div><div class="ie-map-coverage" data-ie-map-coverage hidden></div><div class="ie-point"><div class="ie-point-label"><span data-ie-selection-label>Selected point</span><button type="button" class="ie-thinnest" data-ie-thinnest aria-label="'+eye+' select lowest available pachymetry">Thinnest point</button></div><output class="ie-point-coordinate" data-ie-location></output><div class="ie-point-status" data-ie-point-status></div><div class="ie-estimate-status" data-ie-estimate-status hidden></div>'+['x','y'].map(axis=>'<label class="ie-range" for="'+id+'-'+eye+'-'+axis+'"><span>'+axis.toUpperCase()+'</span><input id="'+id+'-'+eye+'-'+axis+'" data-ie-axis="'+axis+'" type="range" min="0" max="0" value="0" step="1" aria-label="'+eye+' selected '+(axis==='x'?'horizontal':'vertical')+' coordinate in millimetres"></label>').join('')+'</div></article>').join('')+'</div>'+
 '<div class="ie-scene-help">Drag either eye to rotate both · Scroll or use +/− to zoom</div><div class="ie-inspector" aria-live="polite"><table><thead><tr><th scope="col">At the selected point</th><th scope="col">OD</th><th scope="col">OS</th></tr></thead><tbody>'+FIELDS.map(f=>'<tr><th scope="row">'+esc(LABELS[f])+'</th>'+EYES.map(e=>'<td data-ie-read="'+e+'-'+f+'">Unavailable</td>').join('')+'</tr>').join('')+'</tbody></table></div>'+
 '<footer class="ie-footer"><span data-ie-boundary-note></span><span>Initial selection: lowest reconstructed pachymetry for report images, or lowest mapped pachymetry for native data. Unavailable areas may contain a lower minimum.</span><span>Posterior elevation keeps its own reference. Iris, sclera and peripheral cornea are reference anatomy.</span><span>Coordinates: +y superior · +x OD nasal / OS temporal</span><span>Stripes mark narrow-gap estimates. Crosshatching marks uncertain report colors, without an exact value. Map view shows the full available map in 2D; unavailable surface heights stay unavailable.</span><span data-ie-quality></span></footer><details class="ie-method"><summary>What this reconstruction represents</summary><div class="ie-notes" data-ie-notes></div><p>Report images give an approximate corneal shape from anterior elevation and its printed reference sphere. Local supported measurements determine the visible surface; unsupported regions remain open. A partial reconstruction shows only supported patches.</p><p>Native coordinates retain their supplied physical positions. Native pachymetry is an independent device measurement and is not replaced by a vertical or paired-point front/back gap. With report images, the inner boundary is derived from available thickness along the reconstructed front-surface normal.</p><p>Measurement colors are opaque and unlit so the iris and reflections cannot change their meaning. The numerical legend and contour levels use the same scale. Compatible sources share bounds across both eyes and available visits; different map definitions retain separate bounds. Colors show measurement values, not diagnostic categories. Surface maps use independent source samples on the retained 3D surface. Map view instead shows the full map at its physical x/y coordinates, including places without a reconstructed surface height. It is a 2D projection. Gray means unavailable. Stripes mark bounded estimates; crosshatching shows uncertain report-color previews without assigning an exact value. These never replace the original source values, minimum or calculator inputs. Report colors and local source reconstruction remain approximate. Map colors use detailed report samples; point readings and the minimum use the retained reconstruction. A differing report color sample is shown separately. Coverage uses the full printed map circle in Map view and the retained surface in 3D. Uncertain report colors are counted separately from accepted support. Coverage is not an accuracy score. Baseline and latest are independent reconstructions, not a registered deformation. Report images cannot establish a complete 1:1 whole-eye replica.</p></details><div class="ie-error" role="alert" hidden></div></div>';
 host.replaceChildren(root);
 function rotation(){const c=Math.cos(state.yaw),s=Math.sin(state.yaw),a=Math.cos(state.pitch),b=Math.sin(state.pitch);return [c,s*b,-s*a,0,a,b,s,-c*b,c*a];}
 function rotate(p){const r=rotation();return [r[0]*p[0]+r[3]*p[1]+r[6]*p[2],r[1]*p[0]+r[4]*p[1]+r[7]*p[2],r[2]*p[0]+r[5]*p[1]+r[8]*p[2]];}
 function commonScale(){const boxes=[...root.querySelectorAll('.ie-scene')].map(e=>e.getBoundingClientRect()).filter(b=>b.width>0&&b.height>0);return (boxes.length?Math.min(...boxes.map(b=>Math.min(b.width/14.5,b.height/13.2))):1)*state.zoom;}
 function commonMapScale(){const boxes=[...root.querySelectorAll('.ie-scene')].map(e=>e.getBoundingClientRect()).filter(b=>b.width>0&&b.height>0),radii=EYES.map(e=>{const m=modelFor(reportFor(e))?.model,g=m&&C.getMapField(C.prepare(m),state.color,state.estimates);return g?Math.max(Math.abs(g.xMin),Math.abs(g.xMax),Math.abs(g.yMin),Math.abs(g.yMax)):0;}),diameter=2*Math.max(3,...radii);return (boxes.length?Math.min(...boxes.map(b=>Math.min(b.width,b.height)/(diameter+1.4))):1)*state.zoom;}
 function drawAll(){if(!dead)EYES.forEach(e=>views[e]?.draw());}
 function resizeAll(){if(!dead)EYES.forEach(e=>views[e]?.resize());}
 function reportFor(eye){const matched=sets[eye].filter(s=>s.visit===state.visit);return matched.length===1?matched[0]:null;}
 function modelFor(report){if(!report)return null;if(!prepared.has(report)){try{if(!global.NKPIIntegratedModel)throw Error('The integrated corneal model module is unavailable.');prepared.set(report,{model:global.NKPIIntegratedModel.fromReport(report)});}catch(error){prepared.set(report,{model:null,error:error.message});}}return prepared.get(report);}
 function sourceRange(model,field){
  if(!model)return null;const a=M.getFieldRange(model,field),g=C.getMapField(C.prepare(model),field,false),b=g?.range,preview=g?.previewValues?.filter(finite)||[];
  if(!a&&!b&&!preview.length)return null;let min=Math.min(a?.min??Infinity,b?.min??Infinity,...preview),max=Math.max(a?.max??-Infinity,b?.max??-Infinity,...preview);
  // Numerical resampling can add sub-ulp drift to an otherwise constant field.
  // Do not stretch floating-point noise into a full color scale.
  if(max-min<Math.max(1,Math.abs(min),Math.abs(max))*1e-10)min=max=a?.min??b?.min??preview[0];
  return {min,max,count:(a?.count||0)+(b?.count||0)+preview.length};
 }
 function makeRanges(current){
  const eligible=EYES.flatMap(eye=>['first','latest'].flatMap(visit=>{const matching=sets[eye].filter(s=>s.visit===visit);return matching.length===1?[{eye,visit,model:modelFor(matching[0])?.model}]:[];})).filter(q=>q.model);
  const ranges={OD:{},OS:{}};
  for(const eye of EYES){const model=current[eye]?.model;if(!model)continue;
   for(const field of FIELDS){if(!sourceRange(model,field))continue;const signature=M.rangeSignature(model,field),group=eligible.filter(q=>M.rangeSignature(q.model,field)===signature&&sourceRange(q.model,field)),bounds=group.map(q=>sourceRange(q.model,field));
    const scale=M.makeScale(field,{min:Math.min(...bounds.map(b=>b.min)),max:Math.max(...bounds.map(b=>b.max))});
    ranges[eye][field]={...scale,shared:new Set(group.map(q=>q.eye)).size>1,groupedAcrossVisits:new Set(group.map(q=>q.visit)).size>1};
   }
  }return ranges;
 }
 function createView(eye,source,range,error){
  const el=root.querySelector('[data-ie-eye="'+eye+'"]'),canvas=el.querySelector('.ie-geometry'),overlay=el.querySelector('.ie-overlay'),ctx=overlay.getContext('2d');
  const vertices=source?.vertices||[],nx=source?.nx||0,ny=source?.ny||0,axisX=source?.axisX||[],axisY=source?.axisY||[];
  const hasGeometry=!!source&&(source.hasPatientGeometry??source.kind!=='reference')&&source.triangles?.length>0;
  const approximate=source?.sourceKind==='report-image'||source?.mapSource==='image',known=vertices.filter(Boolean),radius=source?.radius||4.5;
  const sourceLabel=source?.sourceLabel||(source?.kind==='native'?'Native coordinates':source?.kind==='estimated'?'Report-image approximation':'Patient surface unavailable');
  const limits=el.querySelector('[data-coverage]');limits.textContent=source?((source.partial?'Partial reconstruction · ':hasGeometry?'Reconstructed field: ':'Map field: ')+(radius*2).toFixed(1)+' mm'):'';
  el.querySelector('[data-ie-source]').textContent=source?sourceLabel:(state.visit==='latest'?'Latest':'Baseline')+' · no linked scan';
  const empty=el.querySelector('[data-ie-empty]');empty.hidden=hasGeometry;empty.textContent=source?'Patient surface geometry is unavailable. Available source measurements can still be inspected below.':error||'Import and verify this eye’s report, then calculate to link its corneal data.';
  const centerIndex=(a)=>a.reduce((best,v,i)=>Math.abs(v)<Math.abs(a[best])?i:best,0);
  const cx=centerIndex(axisX),cy=centerIndex(axisY);
  const report=reportFor(eye),saved=selection.get(report),thinnest=source?M.findThinnest(source):null;
  const minimumLabel=approximate?'Lowest reconstructed pachymetry':'Lowest mapped pachymetry';
  const fullSurfaceIndices=new Set((source?.triangles||[]).flat()),displayPrepared=source?C.prepare(source):null;
  let mapPoint=report?mapSelection.get(report)||null:null;
  const displayField=()=>displayPrepared&&state.color!=='shape'?(state.mapView?C.getMapField:C.getField)(displayPrepared,state.color,state.estimates):null;
  const pointCoordinates=()=>state.mapView&&mapPoint?{...mapPoint}:nx?{x:axisX[selected%nx],y:axisY[Math.floor(selected/nx)]}:null;
  const displaySample=()=>{const p=pointCoordinates(),g=displayField();return p&&g?C.sample(g,p.x,p.y):null;};
  const displayStatus=()=>{const p=pointCoordinates(),g=displayField();return p&&g?C.sampleStatus(g,p.x,p.y):null;};
  const mapReading=field=>{const p=pointCoordinates(),g=displayPrepared&&C.getMapField(displayPrepared,field,state.estimates);return p&&g?C.sample(g,p.x,p.y):null;};
  const mapStatus=field=>{const p=pointCoordinates(),g=displayPrepared&&C.getMapField(displayPrepared,field,state.estimates);return p&&g?C.sampleStatus(g,p.x,p.y):null;};
  const selectedValues=()=>Object.fromEntries(FIELDS.map(f=>[f,state.mapView&&mapPoint?mapReading(f)?.value??null:vertices[selected]?.[f]??null]));
  function readingText(field){if(state.mapView&&mapPoint){const p=mapReading(field);return p?numeric(p.value,field,approximate||p.estimated)+(p.estimated?' (est.)':''):mapStatus(field)?.status===3?'Uncertain':'Unavailable';}return numeric(vertices[selected]?.[field],field,approximate);}
  function coverageText(){const q=displayField()?.coverage;if(!q)return '';const u=q.uncertain??q.clipped??0;return (approximate?'Report support ':'Source ')+coveragePercent(q.source,q.total)+' · Estimated '+coveragePercent(q.estimated,q.total)+' · Color uncertain '+coveragePercent(u,q.total)+' · Unavailable '+coveragePercent(q.unavailable-u,q.total);}

  const selectedHasSurface=()=>{const p=pointCoordinates();return state.mapView&&mapPoint?!!p&&C.hasSurface(displayPrepared,p.x,p.y):hasGeometry&&fullSurfaceIndices.has(selected);};
  let selected=finite(saved)?saved:cy*nx+cx,W=0,H=0,scale=1,dpr=1,disposed=false,gl=null,fallback=null,contextLost=false;
  if(!finite(saved)){const candidates=vertices.map((v,i)=>({v,i})).filter(q=>q.v?.front?.every(finite));candidates.sort((a,b)=>Math.hypot(...a.v.front.slice(0,2))-Math.hypot(...b.v.front.slice(0,2))||a.i-b.i);selected=thinnest?.index??candidates[0]?.i??selected;}
  const sectionAngle=thinnest?Math.atan2(thinnest.y,thinnest.x):0,cutCos=Math.cos(sectionAngle),cutSin=Math.sin(sectionAngle);
  const inCut=(point,strict=false)=>{const x=point[0]*cutCos+point[1]*cutSin,y=-point[0]*cutSin+point[1]*cutCos;return strict?x>1e-8&&y< -1e-8:x>=-1e-8&&y<=1e-8;};
  const sliderX=el.querySelector('[data-ie-axis=x]'),sliderY=el.querySelector('[data-ie-axis=y]');sliderX.max=Math.max(0,nx-1);sliderY.max=Math.max(0,ny-1);sliderX.disabled=sliderY.disabled=!known.length;
  let resources=[],geometry={},program=null,attrs={},uniforms={},shaderHandles=[],mapTextures=new Map();
  const closest=[...known].sort((a,b)=>Math.hypot(...a.front.slice(0,2))-Math.hypot(...b.front.slice(0,2)))[0];
  const apex=closest?.front[2]||0,focus=apex-1.3,limbus=Math.max(5.7,radius+.35),globeRadius=Math.max(12,limbus+.5),R=finite(source?.bfs)&&source.bfs>radius?source.bfs:Math.max(7.8,radius+.4);
  const sag=r=>Math.sqrt(Math.max(.001,R*R-r*r))-R,border=known.filter(v=>Math.hypot(...v.front.slice(0,2))>radius-.25),offset=border.length?median(border.map(v=>v.front[2]-sag(Math.hypot(...v.front.slice(0,2))))):apex;
  const d0=-radius/Math.sqrt(Math.max(.001,R*R-radius*radius)),d1=-limbus/Math.sqrt(globeRadius*globeRadius-limbus*limbus),L=limbus-radius,z0=sag(radius)+offset,limbusZ=z0+L*(d0+d1)/2,globeCenter=limbusZ-Math.sqrt(globeRadius*globeRadius-limbus*limbus);
  function refHeight(r){const t=clamp((r-radius)/L,0,1);return (2*t*t*t-3*t*t+1)*z0+(t*t*t-2*t*t+t)*L*d0+(-2*t*t*t+3*t*t)*limbusZ+(t*t*t-t*t)*L*d1;}
  function refSlope(r){const t=clamp((r-radius)/L,0,1);return ((6*t*t-6*t)*z0+(3*t*t-4*t+1)*L*d0+(-6*t*t+6*t)*limbusZ+(3*t*t-2*t)*L*d1)/L;}
  const keep=ids=>!ids.every(i=>inCut(vertices[i].front));
  function project(v){if(state.mapView)return [W*.5+v[0]*scale,H*.5-v[1]*scale,0];const q=rotate([v[0],v[1],v[2]-focus]);return [W*.5+q[0]*scale,H*.5-q[1]*scale,q[2]];}
  function surfaceMesh(side,cut){const p=vertices.map(v=>v?.[side]||[0,0,0]),n=vertices.map(()=>[0,0,0]),tri=(source?.triangles||[]).filter(ids=>ids.every(i=>vertices[i]?.[side])&&(!cut||keep(ids)));for(const ids of tri){let no=cross(sub(p[ids[1]],p[ids[0]]),sub(p[ids[2]],p[ids[0]]));if((side==='front'?1:-1)*no[2]<0)no=mul(no,-1);for(const i of ids)n[i]=add(n[i],no);}return mesh(p,n.map(unit),tri,vertices.map((_,i)=>i));}
  function mesh(points,normals,triangles,sourceIndices=null){
   const oriented=triangles.map(ids=>{const [a,b,c]=ids,no=cross(sub(points[b],points[a]),sub(points[c],points[a]));return dot(no,normals[a])<0?[a,c,b]:ids;});
   const out={points,normals,triangles:oriented,sourceIndices,count:oriented.length*3,chunks:[],field:null};
   if(!gl)return out;
   // Nonindexed draw chunks avoid WebGL1's16-bit index limit and preserve
   // every source vertex even for larger native grids.
   for(let first=0;first<oriented.length;first+=16000){const ids=oriented.slice(first,first+16000).flat(),data=new Float32Array(ids.length*8),buffer=gl.createBuffer();resources.push(buffer);out.chunks.push({ids,data,buffer,count:ids.length});}
   fillMesh(out);return out;
  }
  function fillMesh(m){if(!gl)return;const field=state.color;for(const chunk of m.chunks){
   for(let first=0;first<chunk.ids.length;first+=3){const ids=chunk.ids.slice(first,first+3),values=ids.map(index=>{const sourceIndex=m.sourceIndices?.[index];return sourceIndex===undefined?null:vertices[sourceIndex]?.[field];}),valid=values.every(value=>finite(value)&&(field!=='thickness'||value>0)),scalar=values.map(value=>field==='posterior'?Math.abs(value):value),hasGradient=valid&&Math.max(...scalar)-Math.min(...scalar)>1e-10;
    ids.forEach((index,j)=>{const value=values[j];chunk.data.set([...m.points[index],...m.normals[index],finite(value)?(field==='posterior'?Math.abs(value):value):0,valid?(hasGradient?1:2):0],(first+j)*8);});
   }gl.bindBuffer(gl.ARRAY_BUFFER,chunk.buffer);gl.bufferData(gl.ARRAY_BUFFER,chunk.data,gl.DYNAMIC_DRAW);
  }m.field=field;}
  function walls(){const p=[],n=[],tri=[],edges=[];
   // The cut is defined in physical x/y, independent of axis order, spacing
   // or whether zero is a grid coordinate. Only an edge shared by a retained
   // and deliberately removed source triangle receives a thickness wall.
   const edgeCounts=new Map();for(const ids of source?.triangles||[]){const retained=keep(ids);for(const [a,b]of [[ids[0],ids[1]],[ids[1],ids[2]],[ids[2],ids[0]]]){const key=Math.min(a,b)+':'+Math.max(a,b),entry=edgeCounts.get(key)||{a,b,kept:0,cut:0};entry[retained?'kept':'cut']++;edgeCounts.set(key,entry);}}
   for(const e of edgeCounts.values())if(e.kept===1&&e.cut>=1&&vertices[e.a]?.back&&vertices[e.b]?.back)edges.push([e.a,e.b]);
   for(const [a,b]of edges){const v=vertices[a],w=vertices[b],q=p.length,no=unit(cross(sub(w.front,v.front),sub(v.back,v.front)));p.push(v.front,w.front,w.back,v.back);n.push(no,no,no,no);tri.push([q,q+1,q+2],[q,q+2,q+3]);}const result=mesh(p,n,tri);result.edges=edges;return result;}
  function ring(kind,cut){const p=[],n=[],tri=[],N=96,J=kind==='globe'?44:kind==='iris'?1:22;for(let j=0;j<=J;j++)for(let i=0;i<=N;i++){const a=i*2*PI/N;let pt,no;if(kind==='globe'){const t=Math.asin(limbus/globeRadius)+(PI-Math.asin(limbus/globeRadius)-.00001)*j/J;no=[Math.sin(t)*Math.cos(a),Math.sin(t)*Math.sin(a),Math.cos(t)];pt=[globeRadius*no[0],globeRadius*no[1],globeCenter+globeRadius*no[2]];}else if(kind==='iris'){const r=(limbus-.12)*j/J;no=[0,0,1];pt=[r*Math.cos(a),r*Math.sin(a),limbusZ-.44];}else{const r=radius+(limbus-radius)*j/J,d=refSlope(r);no=unit([-d*Math.cos(a),-d*Math.sin(a),1]);pt=[r*Math.cos(a),r*Math.sin(a),refHeight(r)];}p.push(pt);n.push(no);if(i&&j){const b=j*(N+1)+i,a=b-1,c=a-N-1,d=b-N-1,mid=(i-.5)*2*PI/N;if(!cut||!inCut([Math.cos(mid),Math.sin(mid)]))tri.push([a,c,b],[b,c,d]);}}return mesh(p,n,tri);}
  function textureFor(grid,bounds){
   if(!gl||!grid||!bounds)return null;
   const key=state.color+':'+state.estimates+':'+bounds.min+':'+bounds.max;
   if(mapTextures.has(key))return mapTextures.get(key);
   const bytes=new Uint8Array(grid.width*grid.height*4),span=bounds.max-bounds.min;
   for(let i=0;i<grid.values.length;i++){
    const status=grid.status[i],value=status===3?grid.previewValues?.[i]:grid.values[i],valid=[1,2,3].includes(status)&&finite(value),q=valid?Math.round(clamp((value-bounds.min)/span,0,1)*65535):0;
    bytes[i*4]=Math.floor(q/256);bytes[i*4+1]=q%256;bytes[i*4+2]=valid?status:0;bytes[i*4+3]=255;
   }
   const texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.pixelStorei(gl.UNPACK_ALIGNMENT,1);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,grid.width,grid.height,0,gl.RGBA,gl.UNSIGNED_BYTE,bytes);mapTextures.set(key,texture);return texture;
  }
  function initGL(){
   gl=canvas.getContext('webgl',{antialias:true,alpha:false,preserveDrawingBuffer:true});if(!gl)return false;
   const vs='attribute vec3 p;attribute vec3 n;attribute float value;attribute float valid;uniform mat3 rot;uniform float scale;uniform vec2 size;uniform float focus;varying vec3 N;varying vec3 P;varying float K;varying float V;void main(){vec3 q=rot*(p-vec3(0.,0.,focus));gl_Position=vec4(q.x*scale*2./size.x,q.y*scale*2./size.y,-q.z/80.,1.);N=rot*n;P=p;K=value;V=valid;}';
   const fs=`precision highp float;
    uniform int material;uniform float tint;uniform float alpha;uniform vec2 bounds;
    uniform float analysis;uniform float contours;uniform float useMap;
    uniform sampler2D mapData;uniform vec4 mapRect;uniform vec2 mapSize;
    uniform vec3 palette0;uniform vec3 palette1;uniform vec3 palette2;uniform vec3 palette3;uniform vec3 palette4;
    varying vec3 N;varying vec3 P;varying float K;varying float V;
    vec3 heat(float k){float t=clamp((k-bounds.x)/max(.00001,bounds.y-bounds.x),0.,1.);
     if(t<.25)return mix(palette0,palette1,t*4.);
     if(t<.5)return mix(palette1,palette2,(t-.25)*4.);
     if(t<.75)return mix(palette2,palette3,(t-.5)*4.);
     return mix(palette3,palette4,(t-.75)*4.);
    }
    vec3 mapNode(vec2 ij){vec4 p=texture2D(mapData,(ij+vec2(.5))/mapSize);float status=floor(p.b*255.+.5);return vec3(bounds.x+(floor(p.r*255.+.5)*256.+floor(p.g*255.+.5))/65535.*(bounds.y-bounds.x),status,0.);}
    float supported(vec3 p){return step(.5,p.y)*(1.-step(2.5,p.y));}
    vec3 mapValue(vec2 xy){
     vec2 f=(xy-mapRect.xy)/(mapRect.zw-mapRect.xy)*(mapSize-vec2(1.));
     if(f.x<-.00001||f.y<-.00001||f.x>mapSize.x-1.+.00001||f.y>mapSize.y-1.+.00001)return vec3(0.);
     f=clamp(f,vec2(0.),mapSize-vec2(1.));vec3 nearest=mapNode(floor(f+vec2(.5)));if(nearest.y>2.5)return nearest;if(supported(nearest)<.5)return vec3(0.);
     vec2 i=min(floor(f),mapSize-vec2(2.)),w=f-i;vec3 a=mapNode(i),b=mapNode(i+vec2(1.,0.)),c=mapNode(i+vec2(0.,1.)),d=mapNode(i+vec2(1.));
     vec4 weights=vec4((1.-w.x)*(1.-w.y),w.x*(1.-w.y),(1.-w.x)*w.y,w.x*w.y);
     vec4 have=vec4(supported(a),supported(b),supported(c),supported(d));
     if(dot(vec4(1.)-have,step(vec4(.00000001),weights))>.5)return nearest;
     weights*=step(vec4(.00000001),weights);weights/=dot(weights,vec4(1.));float value=dot(weights,vec4(a.x,b.x,c.x,d.x));
     float estimated=max(max(step(1.5,a.y)*step(.00000001,weights.x),step(1.5,b.y)*step(.00000001,weights.y)),max(step(1.5,c.y)*step(.00000001,weights.z),step(1.5,d.y)*step(.00000001,weights.w)));
     vec4 contributing=mix(vec4(value),vec4(a.x,b.x,c.x,d.x),step(vec4(.00000001),weights));float low=min(min(contributing.x,contributing.y),min(contributing.z,contributing.w)),high=max(max(contributing.x,contributing.y),max(contributing.z,contributing.w));return vec3(value,1.+estimated,step(.000001,high-low));
    }
    void main(){vec3 n=normalize(N);if(!gl_FrontFacing)n=-n;
     vec3 light=normalize(vec3(-.7,.85,1.6));float d=max(0.,dot(n,light)),f=pow(1.-abs(n.z),2.),s=pow(max(0.,dot(n,normalize(light+vec3(0.,0.,1.)))),100.);
     if(material==4){
      vec3 point=useMap>.5?mapValue(P.xy):vec3(K,V>.999?1.:0.,V<1.5?1.:0.);
      if(point.y<.5){gl_FragColor=vec4(.38,.42,.46,1.);return;}
      vec3 color=heat(point.x);float t=clamp((point.x-bounds.x)/max(.00001,bounds.y-bounds.x),0.,1.);
      if(point.y>2.5){float hatch=max(step(.76,fract((P.x+P.y)*7.)),step(.76,fract((P.x-P.y)*7.)));color=mix(color,vec3(.45,.29,.57),.28);color=mix(color,vec3(.91,.79,.98),hatch*.70);gl_FragColor=vec4(color,1.);return;}
      float edge=min(abs(t-.25),min(abs(t-.5),abs(t-.75)));
      float line=(1.-smoothstep(.002,.006,edge))*contours*point.z;
      color=mix(color,vec3(.055,.075,.10),line*.62);
      if(point.y>1.5){float hatch=step(.78,fract((P.x+P.y)*9.));color=mix(color,vec3(.96,.88,.70),hatch*.32);}
      gl_FragColor=vec4(color,1.);return;
     }
     if(material==0){vec3 base=analysis>.5?vec3(.36,.41,.46):vec3(.83,.88,.92);gl_FragColor=vec4(base*(.48+.46*d)+vec3(.11)*s,1.);return;}
     if(material==1){if(analysis>.5){gl_FragColor=vec4(.10,.14,.19,1.);return;}float r=length(P.xy),a=atan(P.y,P.x);if(r<1.65){gl_FragColor=vec4(.008,.016,.024,1.);return;}float q=(r-1.65)/3.93,fib=.5+.24*sin(a*137.+sin(r*2.7+a*11.)*2.)+.13*sin(a*237.-r*4.)+.06*sin(a*319.+r*1.6);vec3 c=mix(vec3(.045,.15,.19),vec3(.22,.41,.46),fib);c*=.83+.17*sin(q*11.);c*=1.-.65*smoothstep(.88,1.,q);gl_FragColor=vec4(c*(.75+.25*d),1.);return;}
     if(material==2){float t=tint*step(.999,V);vec3 base=mix(vec3(.66,.85,.94),heat(K),t*.72),c=base*(.70+.30*d)+vec3(.72,.83,.90)*s*.8;float a=alpha+.44*f+.38*s+t*.14;gl_FragColor=vec4(clamp(c,0.,1.),clamp(a,0.,.88));return;}
     gl_FragColor=vec4(vec3(.78,.66,.43)*(.60+.40*d),1.);
    }`;
   function shader(type,text){const s=gl.createShader(type);shaderHandles.push(s);gl.shaderSource(s,text);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;}
   program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,vs));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,fs));gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));gl.useProgram(program);
   for(const key of ['p','n','value','valid'])attrs[key]=gl.getAttribLocation(program,key);for(const key of ['rot','scale','size','focus','material','tint','alpha','bounds','analysis','contours','palette0','palette1','palette2','palette3','palette4','useMap','mapData','mapRect','mapSize'])uniforms[key]=gl.getUniformLocation(program,key);
   const emptyTexture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,emptyTexture);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([0,0,0,255]));mapTextures.set('__empty',emptyTexture);
   geometry={front:surfaceMesh('front',false),frontCut:surfaceMesh('front',true),back:surfaceMesh('back',false),backCut:surfaceMesh('back',true),walls:walls(),globe:ring('globe',false),iris:ring('iris',false),peripheral:ring('peripheral',false),peripheralCut:ring('peripheral',true)};return true;
  }
  function cleanupGL(){if(gl){for(const texture of mapTextures.values())gl.deleteTexture(texture);for(const b of resources)gl.deleteBuffer(b);for(const s of shaderHandles)gl.deleteShader(s);if(program)gl.deleteProgram(program);}resources=[];shaderHandles=[];mapTextures=new Map();program=null;}
  if(hasGeometry){try{if(!initGL())fallback='WebGL unavailable · source mesh view';}catch(_){cleanupGL();gl=null;fallback='3D graphics unavailable · source mesh view';}}
  if(fallback){geometry={front:surfaceMesh('front',false),frontCut:surfaceMesh('front',true),back:surfaceMesh('back',false),backCut:surfaceMesh('back',true),walls:walls()};canvas.hidden=true;const label=document.createElement('span');label.className='ie-fallback-label';label.textContent=fallback;el.querySelector('.ie-scene').appendChild(label);}
  function drawMesh(m,material,alpha,tint=false){if(!m)return;if(m.field!==state.color)fillMesh(m);gl.uniform1i(uniforms.material,material);gl.uniform1f(uniforms.alpha,alpha||0);gl.uniform1f(uniforms.tint,tint?1:0);for(const chunk of m.chunks){gl.bindBuffer(gl.ARRAY_BUFFER,chunk.buffer);for(const [key,size,offset]of [['p',3,0],['n',3,12],['value',1,24],['valid',1,28]]){gl.enableVertexAttribArray(attrs[key]);gl.vertexAttribPointer(attrs[key],size,gl.FLOAT,false,32,offset);}gl.drawArrays(gl.TRIANGLES,0,chunk.count);}}
  function stroke(points,color,width){ctx.beginPath();let on=false;for(const p of points){if(!p){on=false;continue;}const q=project(p);if(on)ctx.lineTo(q[0],q[1]);else ctx.moveTo(q[0],q[1]);on=true;}ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke();}
  let rasterImage=null,rasterDepth=null;
  function colorSample(grid,x,y){const sample=C.sample(grid,x,y);if(sample)return sample;const status=C.sampleStatus(grid,x,y);return status?.status===3&&finite(status.previewValue)?{value:status.previewValue,status:3,gradient:false}:null;}
  function mapPixel(point,xy,bounds,stops){
   if(!point||!bounds)return [97,107,117];
   const t=clamp((point.value-bounds.min)/(bounds.max-bounds.min),0,1),part=t*4,index=Math.min(3,Math.floor(part)),mix=part-index;
   let color=stops[index].map((v,i)=>v+(stops[index+1][i]-v)*mix);
   if(point.status===3){const a=(xy[0]+xy[1])*7,b=(xy[0]-xy[1])*7,hatch=a-Math.floor(a)>=.76||b-Math.floor(b)>=.76?.70:0;return color.map((v,i)=>(v*.72+[.45,.29,.57][i]*255*.28)*(1-hatch)+[.91,.79,.98][i]*255*hatch);}
   if(state.contours&&point.gradient){const edge=Math.min(Math.abs(t-.25),Math.abs(t-.5),Math.abs(t-.75)),smooth=clamp((edge-.002)/.004,0,1),line=(1-smooth*smooth*(3-2*smooth))*.62;for(let i=0;i<3;i++)color[i]=color[i]*(1-line)+[.055,.075,.10][i]*255*line;}
   if(point.status===2){const stripe=(xy[0]+xy[1])*9,hatch=stripe-Math.floor(stripe)>=.78?.32:0;for(let i=0;i<3;i++)color[i]=color[i]*(1-hatch)+[.96,.88,.70][i]*255*hatch;}
   return color;
  }
  let mapRaster=null;
  function mapDraw(){
   const grid=displayField(),bounds=range[state.color];if(!grid||!bounds){ctx.clearRect(0,0,W,H);return;}
   const width=overlay.width,height=overlay.height,key=[width,height,scale,state.color,state.estimates,state.contours,bounds.min,bounds.max].join(':');
   if(!mapRaster||mapRaster.grid!==grid||mapRaster.key!==key){
    const raster=ctx.createImageData(width,height),bytes=raster.data,stops=M.paletteStops(state.color).map(c=>c.map(v=>v*255)),r=grid.radius_mm??Math.max(Math.abs(grid.xMin),Math.abs(grid.xMax));
    for(let py=0;py<height;py++)for(let px=0;px<width;px++){
     const x=((px+.5)/dpr-W*.5)/scale,y=(H*.5-(py+.5)/dpr)/scale,k=(py*width+px)*4;
     const color=Math.hypot(x,y)<=r&&x>=grid.xMin&&x<=grid.xMax&&y>=grid.yMin&&y<=grid.yMax?mapPixel(colorSample(grid,x,y),[x,y],bounds,stops):[9,19,31];
     bytes[k]=Math.round(color[0]);bytes[k+1]=Math.round(color[1]);bytes[k+2]=Math.round(color[2]);bytes[k+3]=255;
    }
    mapRaster={grid,key,raster};
   }
   ctx.putImageData(mapRaster.raster,0,0);
   const p=pointCoordinates();if(p){const a=project([p.x,p.y,0]),s=displaySample(),status=displayStatus(),field=state.color,text=mapPoint?(status?.status===3?'Color uncertain · no exact value':numeric(s?.value,field,approximate||s?.estimated)+(s?.estimated?' · estimate':'')):readingText(field);
    ctx.beginPath();ctx.arc(a[0],a[1],4,0,2*PI);ctx.fillStyle='#fff0bf';ctx.fill();ctx.strokeStyle='#172334';ctx.lineWidth=1;ctx.stroke();ctx.font='12px Arial';ctx.textAlign='left';ctx.textBaseline='middle';const tw=ctx.measureText(text).width,tx=clamp(a[0]+12,7,Math.max(7,W-tw-10)),ty=clamp(a[1]+19,18,H-49);ctx.fillStyle='rgba(9,19,31,.94)';ctx.fillRect(tx-4,ty-11,tw+8,22);ctx.fillStyle='#fff0bf';ctx.fillText(text,tx,ty);
   }
   ctx.textAlign='left';ctx.textBaseline='alphabetic';ctx.font='10px Arial';ctx.fillStyle='#b6c6d6';ctx.fillText('2D · source map coordinates',12,19);
  }
  function quantitativeFallback(){
   // Paint every covered sample directly. Independent antialiased Canvas
   // triangle fills blend at internal seams and corrupt a quantitative color.
   // A depth buffer preserves source holes and the actual projected surfaces.
   const width=overlay.width,height=overlay.height;
   if(!rasterImage||rasterImage.width!==width||rasterImage.height!==height){rasterImage=ctx.createImageData(width,height);rasterDepth=new Float32Array(width*height);}
   const bytes=rasterImage.data;rasterDepth.fill(-Infinity);
   for(let p=0;p<bytes.length;p+=4){bytes[p]=9;bytes[p+1]=19;bytes[p+2]=31;bytes[p+3]=255;}
   const display=displayField(),bounds=range[state.color],stops=M.paletteStops(state.color).map(c=>c.map(v=>v*255)),denominator=bounds?bounds.max-bounds.min:1;
   for(const side of ['back','front']){
    const surface=geometry[side+(state.section?'Cut':'')],projected=surface.points.map(point=>{const q=project(point);return [q[0]*dpr,q[1]*dpr,q[2]];});
    for(const triangle of surface.triangles){
     const p=triangle.map(i=>projected[i]),values=triangle.map(i=>vertices[i]?.[state.color]),valid=side==='front'&&bounds&&values.every(v=>finite(v)&&(state.color!=='thickness'||v>0)),scalar=values.map(v=>state.color==='posterior'?Math.abs(v):v),gradient=valid&&Math.max(...scalar)-Math.min(...scalar)>1e-10;
     const area=(p[1][1]-p[2][1])*(p[0][0]-p[2][0])+(p[2][0]-p[1][0])*(p[0][1]-p[2][1]);if(Math.abs(area)<1e-12)continue;
     const x0=Math.max(0,Math.floor(Math.min(...p.map(v=>v[0])))),x1=Math.min(width-1,Math.ceil(Math.max(...p.map(v=>v[0])))),y0=Math.max(0,Math.floor(Math.min(...p.map(v=>v[1])))),y1=Math.min(height-1,Math.ceil(Math.max(...p.map(v=>v[1]))));
     for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){
      const px=x+.5,py=y+.5,a=((p[1][1]-p[2][1])*(px-p[2][0])+(p[2][0]-p[1][0])*(py-p[2][1]))/area,b=((p[2][1]-p[0][1])*(px-p[2][0])+(p[0][0]-p[2][0])*(py-p[2][1]))/area,c=1-a-b;if(a< -1e-8||b< -1e-8||c< -1e-8)continue;
      const depth=a*p[0][2]+b*p[1][2]+c*p[2][2],pixel=y*width+x;if(depth<rasterDepth[pixel])continue;rasterDepth[pixel]=depth;
      let color=side==='front'?[.38*255,.42*255,.46*255]:[.22*255,.31*255,.38*255];
      const xy=side==='front'&&display?[0,1].map(k=>a*surface.points[triangle[0]][k]+b*surface.points[triangle[1]][k]+c*surface.points[triangle[2]][k]):null;
      const sample=xy?colorSample(display,xy[0],xy[1]):null,point=display?(sample&&bounds&&side==='front'?sample:null):(valid?{value:a*scalar[0]+b*scalar[1]+c*scalar[2],status:1,gradient}:null);
      if(point)color=mapPixel(point,xy||[0,0],bounds,stops);
      const offset=pixel*4;bytes[offset]=Math.round(color[0]);bytes[offset+1]=Math.round(color[1]);bytes[offset+2]=Math.round(color[2]);
     }
    }
   }ctx.putImageData(rasterImage,0,0);
  }
  function fallbackDraw(){
   if(state.color!=='shape'){quantitativeFallback();return;}
   ctx.fillStyle='#09131f';ctx.fillRect(0,0,W,H);const faces=[];
   for(const side of ['back','front']){const surface=geometry[side+(state.section?'Cut':'')];for(const tri of surface.triangles){const p=tri.map(i=>project(surface.points[i]));faces.push({p,z:p.reduce((sum,v)=>sum+v[2],0)/3,n:unit(tri.reduce((sum,i)=>add(sum,surface.normals[i]),[0,0,0])),side});}}
   faces.sort((a,b)=>a.z-b.z);
   for(const f of faces){const normal=rotate(f.n),light=.45+.45*Math.abs(dot(normal,unit([-.7,.85,1.6]))),rgb=[146,195,216].map(v=>Math.round(v*light));ctx.beginPath();f.p.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.closePath();ctx.fillStyle='rgba('+rgb.join(',')+','+(f.side==='front'?0.9:0.55)+')';ctx.fill();}
  }
  function overlayDraw(clear=true){if(clear)ctx.clearRect(0,0,W,H);if(!hasGeometry||rotate([0,0,1])[2]<=0)return;
   if(state.section)for(const [a,b]of geometry.walls?.edges||[]){stroke([vertices[a].front,vertices[b].front],'#d9f3fa',1.6);stroke([vertices[a].back,vertices[b].back],'#cfaf78',1.6);}
   const v=vertices[selected];if(!v)return;const pointOnly=!selectedHasSurface();if(state.section&&!pointOnly&&inCut(v.front,true))return;
   const field=state.color==='shape'?'thickness':state.color,a=project(v.front),derived=!pointOnly&&field==='thickness'&&source.innerBoundaryKind==='thickness-derived'&&v.back&&finite(v.thickness)&&v.thickness>0,b=derived?project(v.back):a;
   if(derived){ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.strokeStyle='#fff0bf';ctx.lineWidth=2;ctx.stroke();}
   for(const q of derived?[a,b]:[a]){ctx.beginPath();ctx.arc(q[0],q[1],pointOnly?5:3.3,0,2*PI);if(!pointOnly){ctx.fillStyle='#fff0bf';ctx.fill();}ctx.strokeStyle=pointOnly?'#fff0bf':'#172334';ctx.lineWidth=pointOnly?1.5:.8;ctx.stroke();}
   const short={thickness:'Thickness',anterior:'Ant. curvature',posterior:'Post. curvature',elevation:'Ant. elevation',posterior_elevation:'Post. elevation'};
   const prefix=state.color==='shape'?(thinnest?.index===selected?(approximate?'Recon. min ':'Min '):!approximate?'Device thickness ':''):(short[field]+' '),text=prefix+numeric(v[field],field,approximate),mid=[(a[0]+b[0])/2,(a[1]+b[1])/2];
   ctx.font='10px Arial';const pointNote='Point only · surface patch unavailable',noteWidth=pointOnly?ctx.measureText(pointNote).width:0;ctx.font='12px Arial';ctx.textBaseline='middle';const tw=ctx.measureText(text).width,tx=clamp(mid[0]+33,Math.max(tw,noteWidth)+10,W-12),ty=clamp(mid[1]+20,27,H-35);ctx.beginPath();ctx.moveTo(mid[0],mid[1]);ctx.lineTo(tx-tw-4,ty);ctx.strokeStyle='#b9c4d3';ctx.lineWidth=1;ctx.stroke();ctx.fillStyle='rgba(9,19,31,.93)';ctx.fillRect(tx-tw-5,ty-10,tw+10,20);ctx.textAlign='right';ctx.fillStyle='#fff0bf';ctx.fillText(text,tx,ty);if(pointOnly){ctx.font='10px Arial';const detail=pointNote,dw=noteWidth;ctx.fillStyle='rgba(9,19,31,.93)';ctx.fillRect(tx-dw-5,ty+10,dw+10,18);ctx.fillStyle='#e4c28d';ctx.fillText(detail,tx,ty+19);}
  }
  function draw(){if(disposed||dead)return;if(state.mapView){mapDraw();return;}if(!hasGeometry){ctx.clearRect(0,0,W,H);return;}if(fallback){fallbackDraw();overlayDraw(false);return;}if(!gl||contextLost)return;
   const quantitative=state.color!=='shape';
   gl.viewport(0,0,canvas.width,canvas.height);gl.clearColor(.035,.057,.093,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.useProgram(program);gl.uniformMatrix3fv(uniforms.rot,false,new Float32Array(rotation()));gl.uniform2f(uniforms.size,W,H);gl.uniform1f(uniforms.scale,scale);gl.uniform1f(uniforms.focus,focus);
   const bounds=range[state.color]||{min:0,max:1};gl.uniform2f(uniforms.bounds,bounds.min,bounds.max);gl.uniform1f(uniforms.analysis,quantitative?1:0);gl.uniform1f(uniforms.contours,state.contours?1:0);
   const grid=quantitative?displayField():null,texture=textureFor(grid,bounds);gl.uniform1f(uniforms.useMap,texture?1:0);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture||mapTextures.get('__empty'));gl.uniform1i(uniforms.mapData,0);if(texture){gl.uniform4f(uniforms.mapRect,grid.xMin,grid.yMin,grid.xMax,grid.yMax);gl.uniform2f(uniforms.mapSize,grid.width,grid.height);}

   M.paletteStops(quantitative?state.color:'anterior').forEach((color,i)=>gl.uniform3fv(uniforms['palette'+i],new Float32Array(color)));
   gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.depthMask(true);gl.disable(gl.CULL_FACE);gl.disable(gl.BLEND);drawMesh(geometry.globe,0);drawMesh(geometry.iris,1);if(state.section)drawMesh(geometry.walls,3);
   gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);gl.enable(gl.CULL_FACE);
   for(const face of [gl.FRONT,gl.BACK]){gl.cullFace(face);drawMesh(state.section?geometry.peripheralCut:geometry.peripheral,2,.12,false);drawMesh(state.section?geometry.backCut:geometry.back,2,.10,false);if(!quantitative)drawMesh(state.section?geometry.frontCut:geometry.front,2,.23,false);}
   gl.disable(gl.CULL_FACE);gl.depthMask(true);
   if(quantitative){gl.disable(gl.BLEND);drawMesh(state.section?geometry.frontCut:geometry.front,4,1,true);}
   overlayDraw();
  }
  function legendNumber(value){const signed=state.color==='elevation'||state.color==='posterior_elevation';return (signed&&value>0?'+':'')+(Math.abs(value-Math.round(value))<1e-8?String(Math.round(value)):value.toFixed(Math.abs(value)<1?2:1));}
  function renderLegend(value){
   const legend=el.querySelector('[data-ie-legend]'),r=range[state.color],active=state.color!=='shape'&&!!r;legend.dataset.active=String(active);
   if(!active){legend.textContent=state.color==='shape'?(hasGeometry?'Natural eye · source coordinates unchanged':'Surface geometry unavailable'):LABELS[state.color]+' unavailable';return;}
   const definition=source?.mapDefinitions?.[state.color]?.type,unit=LAYERS.find(l=>l.id===state.color).unit,selectedValue=finite(value)&&(state.color!=='thickness'||value>0)?(state.color==='posterior'?Math.abs(value):value):null;
   const colors=M.paletteStops(state.color).map((rgb,i)=>'rgb('+rgb.map(v=>Math.round(v*255)).join(',')+') '+i*25+'%').join(',');
   const title=LABELS[state.color]+(definition&&['anterior','posterior'].includes(state.color)?' ('+definition.replace(/_/g,' ')+')':'')+' · '+unit;
   const scaleText=(r.shared?'Shared OD/OS scale':'Source scale')+(r.groupedAcrossVisits?' · fixed across visits':'');
   const direction=state.color==='thickness'?'Thinner → thicker':state.color==='anterior'||state.color==='posterior'?'Flatter → steeper':'Below reference → above reference';
   legend.innerHTML='<div class="ie-legend-title">'+esc(title)+'</div><div class="ie-legend-bar" data-ie-legend-bar data-min="'+r.min+'" data-max="'+r.max+'" style="background:linear-gradient(90deg,'+colors+')"><span class="ie-legend-selected" data-ie-legend-selected'+(selectedValue===null?' hidden':' data-value="'+selectedValue+'" style="left:'+clamp((selectedValue-r.min)/(r.max-r.min)*100,0,100)+'%"')+'></span></div><div class="ie-legend-ticks">'+r.ticks.map(v=>'<span data-ie-legend-tick data-value="'+v+'">'+esc(legendNumber(v))+'</span>').join('')+'</div><div class="ie-legend-caption" data-ie-legend-caption>'+esc(direction)+'<br>'+esc(scaleText)+'</div><div class="ie-legend-selected-value">Selected: '+esc(readingText(state.color))+' <span class="ie-map-key"><span class="ie-missing-key">Gray: unavailable</span><span class="ie-estimated-key"'+(state.estimates&&displayField()?.coverage.estimated?'':' hidden')+'>Stripes: estimate</span><span class="ie-uncertain-key"'+(displayField()?.coverage.uncertain?'':' hidden')+'>Crosshatch: color uncertain</span></span></div>';
  }
  function readout(){
   const v=vertices[selected],values=selectedValues(),p=pointCoordinates(),grid=displayField(),mapActive=state.mapView&&!!mapPoint;
   for(const key of FIELDS){const cell=root.querySelector('[data-ie-read="'+eye+'-'+key+'"]');cell.dataset.missing=String(!finite(values[key])||(key==='thickness'&&values[key]<=0));cell.dataset.estimated=String(mapActive&&mapReading(key)?.estimated===true);cell.textContent=readingText(key);}
   el.querySelector('[data-ie-location]').textContent=p?'x '+(p.x>=0?'+':'')+p.x.toFixed(2)+', y '+(p.y>=0?'+':'')+p.y.toFixed(2)+' mm':'No source point';
   const nearest=(axis,value)=>axis.reduce((best,v,i)=>Math.abs(v-value)<Math.abs(axis[best]-value)?i:best,0),axes=state.mapView&&grid?[grid.axisX,grid.axisY]:[axisX,axisY];
   [sliderX,sliderY].forEach((slider,k)=>{slider.max=Math.max(0,axes[k].length-1);slider.disabled=!axes[k].length;slider.value=p?nearest(axes[k],k?p.y:p.x):0;slider.setAttribute('aria-valuetext',p?(k?p.y:p.x).toFixed(2)+' mm':'Unavailable');});
   el.dataset.selectedIndex=selected;el.dataset.sourceGeometry=source?.kind||'unavailable';el.dataset.partial=String(!!source?.partial);el.dataset.mapView=String(state.mapView);
   const isMinimum=!mapActive&&!!thinnest&&selected===thinnest.index,selectionLabel=el.querySelector('[data-ie-selection-label]'),reset=el.querySelector('[data-ie-thinnest]');
   selectionLabel.textContent=mapActive?'Selected map location':isMinimum?minimumLabel:thinnest?'Selected point':'Selected point · thickness unavailable';reset.disabled=!thinnest;reset.setAttribute('aria-label',eye+' select '+minimumLabel.toLowerCase());reset.setAttribute('aria-pressed',String(isMinimum));el.dataset.selectionKind=mapActive?'map':isMinimum?'minimum':thinnest?'manual':'no-thickness';
   renderLegend(values[state.color]);
   const coverage=el.querySelector('[data-ie-map-coverage]');coverage.hidden=!grid||state.color==='shape';coverage.innerHTML=grid?'<span class="ie-map-coverage-heading">'+(state.mapView?'Full map sampling area · independent of 3D height':'Map samples on supported surface')+'</span><span>'+esc(coverageText())+'</span>':'';coverage.title=state.mapView?'Coverage uses the selected map’s full physical circle, including locations without reconstructed surface height. Report colors remain approximate. Coverage is not accuracy.':'Coverage of map samples on the retained surface. Report colors remain approximate. Coverage is not accuracy.';
   const shown=displaySample(),status=displayStatus(),displayNote=el.querySelector('[data-ie-estimate-status]'),missing=!finite(v?.[state.color]),sourceValue=state.color==='posterior'?Math.abs(v?.[state.color]):v?.[state.color],precision=['anterior','posterior'].includes(state.color)?.05:.5;
   const distinct=approximate&&shown&&finite(sourceValue)&&Math.abs(shown.value-sourceValue)>precision;
   let note=status?.status===3?'Crosshatched color is ambiguous or at an accepted calibration limit. No exact value is assigned.':shown?.status===2?'Estimated display value: '+numeric(shown.value,state.color,true)+' · '+(mapActive?'table estimates are marked (est.).':'source readings below are unchanged.') :!mapActive&&shown&&(missing||distinct)?(approximate?'Report color sample: ':'Map display sample: ')+numeric(shown.value,state.color,approximate)+(missing?' · selected source reading is unavailable.':' · reconstructed point reading retained.') :'';
   displayNote.hidden=!note;displayNote.dataset.estimated=String(shown?.status===2);displayNote.textContent=note;
   const insideCut=!state.mapView&&state.section&&v&&inCut(v.front,true),pointOnly=!!v&&!selectedHasSurface();
   el.querySelector('[data-ie-point-status]').textContent=state.mapView?(mapActive?(approximate?'Table: report-color samples at this map location. ':'Table: supplied map samples at this location. '):'Source-point readings and minimum retained. ')+(!selectedHasSurface()?'3D surface height unavailable here.':'2D map projection; height is not shown.') :pointOnly?'Point measurement available; surrounding surface patch unavailable.':insideCut?'Selected point is inside the viewing cut. Choose Whole surface to show it.':'';
   el.querySelector('[data-ie-location-label]').textContent=state.mapView?'Full map · 2D XY · no inferred surface height':!hasGeometry?'':pointOnly?'Point only · surrounding surface patch unavailable':insideCut?'Selected point is inside the viewing cut · choose Whole surface':state.section?(thinnest?(approximate?'Section through reconstructed minimum':'Section through lowest mapped point'):source.innerBoundaryKind==='native'?'Anterior / supplied posterior surface':source.innerBoundaryKind==='thickness-derived'?'Anterior / thickness-derived inner boundary':'Anterior surface · inner boundary unavailable'):state.color==='shape'?'One surface · All available measurements':'Surface map · source coordinates unchanged';
   limits.textContent=state.mapView&&grid?'Map field: '+(grid.xMax-grid.xMin).toFixed(1)+' mm':source?((source.partial?'Partial reconstruction · ':hasGeometry?'Reconstructed field: ':'Map field: ')+(radius*2).toFixed(1)+' mm'):'';
   empty.hidden=state.mapView?!!grid:hasGeometry;empty.textContent=state.mapView?'This map is unavailable for the selected eye and visit.':source?'Patient surface geometry is unavailable. Available source maps can be opened in Map view.':error||'Import and verify this eye’s report, then calculate to link its corneal data.';
   canvas.style.visibility=state.mapView?'hidden':'';overlay.style.pointerEvents=state.mapView||fallback?'auto':'none';const fallbackLabel=el.querySelector('.ie-fallback-label');if(fallbackLabel)fallbackLabel.hidden=state.mapView;
  }
  function resize(){if(disposed||dead)return;const box=canvas.parentElement.getBoundingClientRect();W=box.width;H=box.height;dpr=Math.min(2,window.devicePixelRatio||1);canvas.width=Math.max(1,Math.round(W*dpr));canvas.height=Math.max(1,Math.round(H*dpr));overlay.width=canvas.width;overlay.height=canvas.height;ctx.setTransform(dpr,0,0,dpr,0,0);scale=state.mapView?commonMapScale():commonScale();draw();}
  function setSelected(i,j){if(!nx||!ny)return;mapPoint=null;if(report)mapSelection.delete(report);selected=clamp(Math.round(j),0,ny-1)*nx+clamp(Math.round(i),0,nx-1);if(report)selection.set(report,selected);readout();draw();}
  function setMapPoint(x,y){const g=displayField();if(!state.mapView||!g||![x,y].every(finite)||x<g.xMin||x>g.xMax||y<g.yMin||y>g.yMax)return false;const i=clamp(Math.round((x-g.xMin)/(g.xMax-g.xMin)*(g.width-1)),0,g.width-1),j=clamp(Math.round((y-g.yMin)/(g.yMax-g.yMin)*(g.height-1)),0,g.height-1),sx=g.axisX[i],sy=g.axisY[j];if(!g.eligible[j*g.width+i])return false;mapPoint={x:sx,y:sy};if(report)mapSelection.set(report,mapPoint);readout();draw();return true;}
  function selectChange(){const g=displayField();if(state.mapView&&g)setMapPoint(g.axisX[+sliderX.value],g.axisY[+sliderY.value]);else setSelected(+sliderX.value,+sliderY.value);}
  function selectThinnest(){if(thinnest)setSelected(thinnest.index%nx,Math.floor(thinnest.index/nx));}
  let drag=null;function down(event){if(state.mapView){const b=overlay.getBoundingClientRect();setMapPoint((event.clientX-b.left-W*.5)/scale,(H*.5-(event.clientY-b.top))/scale);return;}if(!hasGeometry)return;event.currentTarget.setPointerCapture(event.pointerId);drag={x:event.clientX,y:event.clientY};}
  function move(event){if(!drag)return;state.yaw+=(event.clientX-drag.x)*.009;state.pitch=clamp(state.pitch+(event.clientY-drag.y)*.009,-1.25,1.25);drag={x:event.clientX,y:event.clientY};drawAll();}
  function up(){drag=null;}
  function wheel(event){if(!hasGeometry&&!(state.mapView&&displayField()))return;event.preventDefault();state.zoom=clamp(state.zoom*Math.exp(-event.deltaY*.001),.6,1.8);resizeAll();}
  const interaction=fallback?overlay:canvas;if(fallback)overlay.style.pointerEvents='auto';
  function lost(event){event.preventDefault();contextLost=true;const message=el.querySelector('[data-ie-empty]');message.hidden=false;message.textContent='3D graphics were interrupted. Source measurements remain available; switch visits or refresh to reopen the surface.';}
  function restored(){if(disposed)return;contextLost=false;cleanupGL();initGL();empty.hidden=true;resize();}
  sliderX.addEventListener('input',selectChange);sliderY.addEventListener('input',selectChange);interaction.addEventListener('pointerdown',down);interaction.addEventListener('pointermove',move);interaction.addEventListener('pointerup',up);interaction.addEventListener('pointercancel',up);interaction.addEventListener('wheel',wheel,{passive:false});canvas.addEventListener('webglcontextlost',lost);canvas.addEventListener('webglcontextrestored',restored);
  if(interaction!==overlay){overlay.addEventListener('pointerdown',down);overlay.addEventListener('wheel',wheel,{passive:false});}
  function exportCanvas(){draw();const out=document.createElement('canvas');out.width=overlay.width;out.height=overlay.height;const c=out.getContext('2d');c.fillStyle='#09131f';c.fillRect(0,0,out.width,out.height);if(!state.mapView&&!fallback&&hasGeometry)c.drawImage(canvas,0,0);c.drawImage(overlay,0,0);if(!hasGeometry&&!(state.mapView&&displayField())){c.font=Math.round(out.width*.037)+'px Arial';c.fillStyle='#dce6f1';let y=out.height*.4;for(const line of wrap(c,empty.textContent,out.width*.83)){c.fillText(line,out.width*.08,y);y+=out.width*.055;}}return out;}
  function dispose(){disposed=true;sliderX.removeEventListener('input',selectChange);sliderY.removeEventListener('input',selectChange);interaction.removeEventListener('pointerdown',down);interaction.removeEventListener('pointermove',move);interaction.removeEventListener('pointerup',up);interaction.removeEventListener('pointercancel',up);interaction.removeEventListener('wheel',wheel);if(interaction!==overlay){overlay.removeEventListener('pointerdown',down);overlay.removeEventListener('wheel',wheel);}canvas.removeEventListener('webglcontextlost',lost);canvas.removeEventListener('webglcontextrestored',restored);cleanupGL();gl?.getExtension('WEBGL_lose_context')?.loseContext();}
  readout();resize();return {eye,source,model:source,vertices,get geometry(){return geometry;},canvas,overlay,range,draw,resize,project,readout,dispose,exportCanvas,setSelected,setMapPoint,selectThinnest,setSelectedRow:j=>setSelected(selected%nx,j),get selected(){return selected;},get displayField(){return displayField();},getSelectedValues:selectedValues,readingText,getInfo:()=>({eye,visit:state.visit,kind:source?.kind||null,mapSource:source?.mapSource||null,partial:!!source?.partial,sourceLabel,hasData:!!report,hasGeometry,sourceDiameterMm:source?radius*2:null,overlays:source?.overlays||[],availableVisits:sets[eye].map(s=>s.visit),selected,thinnest:thinnest?{...thinnest,label:minimumLabel}:null,minimumLabel,selectionKind:state.mapView&&mapPoint?'map':thinnest?(selected===thinnest.index?'minimum':'manual'):'no-thickness',sectionAngle,selectedHasSurface:selectedHasSurface(),mapRange:range[state.color]?{...range[state.color]}:null,mapCoverage:displayField()?.coverage?{...displayField().coverage}:null,mapView:state.mapView,mapDiameterMm:state.mapView&&displayField()?displayField().xMax-displayField().xMin:null,mapSelection:state.mapView&&mapPoint?{...mapPoint}:null,selectedCoordinates:pointCoordinates(),displaySample:displaySample(),displayStatus:displayStatus(),estimates:state.estimates,webgl:!!gl&&!contextLost,fallback:!!fallback}),reference:{limbus,limbusZ,globeCenter,sourceRadius:radius},getScale:()=>scale};
 }
 function sync(){
  const info=EYES.map(e=>views[e]?.getInfo()),available=info.some(v=>v?.hasGeometry),mapsAvailable=EYES.some(e=>FIELDS.some(f=>views[e]?.range[f]));
  for(const b of root.querySelectorAll('[data-ie-visit]')){b.disabled=!visits.has(b.dataset.ieVisit);b.setAttribute('aria-pressed',String(b.dataset.ieVisit===state.visit));}
  for(const b of root.querySelectorAll('[data-ie-mode]')){b.disabled=!available;b.setAttribute('aria-pressed',String(!state.mapView&&(b.dataset.ieMode==='section')===state.section));}
  const select=root.querySelector('[data-ie-field]');select.value=state.color;for(const option of select.options)option.disabled=option.value!=='shape'&&!EYES.some(e=>views[e]?.range[option.value]);select.disabled=!info.some(v=>v?.hasData);
  const contourToggle=root.querySelector('[data-ie-contours]');contourToggle.checked=state.contours;contourToggle.disabled=state.color==='shape'||!(state.mapView?mapsAvailable:available);contourToggle.closest('label').hidden=state.color==='shape';
  const estimateToggle=root.querySelector('[data-ie-estimates]');estimateToggle.checked=state.estimates;estimateToggle.disabled=state.color==='shape'||!(state.mapView?mapsAvailable:available);estimateToggle.closest('label').hidden=state.color==='shape';
  root.querySelector('.ie-scene-help').textContent=state.mapView?'Click a map to inspect its values · 2D maps include available data outside the reconstructed surface · Stripes: estimate · Crosshatch: color uncertain':state.color==='shape'?'Drag either eye to rotate both · Scroll or use +/− to zoom':'Opaque colors show values on the surface · Map view shows the full available map independently of surface gaps';
  root.querySelectorAll('[data-ie-view],[data-ie-zoom]').forEach(b=>{b.disabled=b.dataset.ieView==='map'? !mapsAvailable:b.hasAttribute('data-ie-zoom')?!(state.mapView?mapsAvailable:available):!available;if(b.hasAttribute('data-ie-view'))b.setAttribute('aria-pressed',String(b.dataset.ieView==='map'&&state.mapView));});root.querySelector('[data-ie-save]').disabled=!info.some(v=>v?.hasData);
  const loaded=info.filter(v=>v?.hasData),allImage=loaded.length&&loaded.every(v=>v.mapSource==='image'),allNative=loaded.length&&loaded.every(v=>v.mapSource==='native');root.querySelector('[data-ie-status]').textContent=!loaded.length?'Import reports to begin':allImage?'Report-image approximation':allNative?'Native source coordinates and maps':'Sources labeled under each eye';
  root.querySelector('[data-ie-boundary-note]').textContent=info.some(v=>v?.kind==='native')?'Native coordinates stay in physical units; device thickness remains an independent measurement.':'Front: elevation + reference sphere · Inner boundary: thickness derived';
  const notes=[];for(const eye of EYES){for(const note of views[eye]?.source?.sourceNotes||[])if(note)notes.push(eye+' — '+note);if(reportFor(eye)?.scan_quality==='warning')notes.push(eye+' — Source quality warning.');}root.querySelector('[data-ie-notes]').textContent=notes.join(' ');root.querySelector('[data-ie-quality]').textContent=EYES.filter(e=>reportFor(e)?.scan_quality==='warning').map(e=>e+' — Source quality warning').join(' · ');
  root.dataset.visit=state.visit;root.dataset.color=state.color;root.dataset.section=String(state.section);root.dataset.estimates=String(state.estimates);root.dataset.mapView=String(state.mapView);for(const eye of EYES)views[eye]?.readout();
 }
 function renderVisit(){for(const eye of EYES){views[eye]?.dispose();delete views[eye];const card=root.querySelector('[data-ie-eye="'+eye+'"]'),old=card.querySelector('.ie-scene');old.innerHTML='<canvas class="ie-geometry" role="img" aria-label="'+eye+' corneal surface; drag to rotate both eyes"></canvas><canvas class="ie-overlay" aria-hidden="true"></canvas><div class="ie-empty" data-ie-empty hidden></div><span class="ie-location-label" data-ie-location-label></span>';}
  const current=Object.fromEntries(EYES.map(eye=>[eye,modelFor(reportFor(eye))])),ranges=makeRanges(current);for(const eye of EYES){const duplicate=sets[eye].filter(s=>s.visit===state.visit).length>1;views[eye]=createView(eye,current[eye]?.model,ranges[eye],duplicate?'Multiple reports are linked to this eye and visit. Resolve the source association before rendering.':current[eye]?.error);}
  sync();resizeAll();root.dataset.ready='true';
 }
 function setVisit(visit){if(dead||!visits.has(visit))return;state.visit=visit;renderVisit();}
 function setState(patch={}){if(dead)return;for(const k of ['yaw','pitch','zoom'])if(finite(patch[k]))state[k]=patch[k];state.pitch=clamp(state.pitch,-1.25,1.25);state.zoom=clamp(state.zoom,.6,1.8);if(typeof patch.section==='boolean'){state.section=patch.section;state.mapView=false;}if(typeof patch.cut==='boolean'){state.section=patch.cut;state.mapView=false;}if(typeof patch.mapView==='boolean')state.mapView=patch.mapView;if(typeof patch.contours==='boolean')state.contours=patch.contours;if(typeof patch.estimates==='boolean')state.estimates=patch.estimates;if(LAYERS.some(l=>l.id===patch.color)){state.color=patch.color;if(state.color==='shape')state.mapView=false;}
  if(patch.view==='reset'){state.mapView=false;state.yaw=-.94;state.pitch=-.13;state.zoom=1;}else if(patch.view==='front'){state.mapView=false;state.yaw=0;state.pitch=0;}else if(patch.view==='profile'){state.mapView=false;state.yaw=-PI/2+.025;state.pitch=0;}else if(patch.view==='map'){state.mapView=true;state.yaw=0;state.pitch=0;state.section=false;if(state.color==='shape')state.color=FIELDS.find(field=>EYES.some(eye=>views[eye]?.range[field]))||'shape';}
  if(patch.visit&&patch.visit!==state.visit&&visits.has(patch.visit)){setVisit(patch.visit);return;}sync();resizeAll();
 }
 function exportFigure({download=true}={}){if(dead)return null;
  const width=1680,pad=36,gap=24,panel=(width-pad*2-gap)/2,top=154,canvases=EYES.map(e=>views[e].exportCanvas()),heights=canvases.map(c=>panel*c.height/c.width),imageHeight=Math.max(...heights),out=document.createElement('canvas');out.width=width;out.height=Math.ceil(top+imageHeight+735);const ctx=out.getContext('2d');ctx.fillStyle='#f7f5fa';ctx.fillRect(0,0,out.width,out.height);ctx.fillStyle='#30243e';ctx.font='500 29px Arial';ctx.fillText('NKPI · Integrated corneal view',pad,43);ctx.font='20px Arial';ctx.fillText((state.visit==='latest'?'Latest':'Baseline')+' · '+(state.mapView?'Full source maps · 2D XY':state.section?'Section through each minimum':'Whole surface')+' · '+LABELS[state.color]+' · Equal physical axes',pad,77);
  EYES.forEach((eye,i)=>{const v=views[eye],x=pad+i*(panel+gap),s=v.source,info=v.getInfo();ctx.fillStyle='#30243e';ctx.font='500 23px Arial';ctx.fillText(eye+' · '+(eye==='OD'?'Right eye':'Left eye'),x,112);ctx.font='17px Arial';const label=s?(info.mapView?'2D source map · '+(info.mapDiameterMm?.toFixed(1)||'—')+' mm':(s.partial?'Partial · ':'')+(s.sourceLabel||info.sourceLabel)+' · '+(s.radius*2).toFixed(1)+' mm'):'No linked scan';ctx.fillText(label,x,140);ctx.drawImage(canvases[i],x,top,panel,heights[i]);ctx.fillStyle='#51425f';ctx.font='17px Arial';let y=top+imageHeight+31;const q=s?.vertices[v.selected],index=v.selected,approx=s?.sourceKind==='report-image'||s?.mapSource==='image';
   if(s&&info.selectedCoordinates){ctx.fillText((info.selectionKind==='map'?'Selected map location':info.selectionKind==='minimum'?info.minimumLabel:'Selected point')+' · x '+info.selectedCoordinates.x.toFixed(2)+', y '+info.selectedCoordinates.y.toFixed(2)+' mm',x,y);y+=29;}
   for(const field of FIELDS){ctx.fillText(LABELS[field]+': '+v.readingText(field),x,y);y+=29;}
   const bounds=v.range[state.color];
   if(bounds){
    ctx.font='16px Arial';ctx.fillStyle='#51425f';ctx.fillText(LABELS[state.color]+' · '+LAYERS.find(l=>l.id===state.color).unit+' · '+(bounds.shared?'Shared OD/OS scale':'Source scale')+(bounds.groupedAcrossVisits?' · fixed across visits':''),x,y+3);y+=19;
    const barW=Math.min(panel-12,650),barH=16,gradient=ctx.createLinearGradient(x,0,x+barW,0);M.paletteStops(state.color).forEach((rgb,j)=>gradient.addColorStop(j/4,'rgb('+rgb.map(v=>Math.round(v*255)).join(',')+')'));ctx.fillStyle=gradient;ctx.fillRect(x,y,barW,barH);
    const value=v.getSelectedValues()[state.color],shown=state.color==='posterior'?Math.abs(value):value;
    if(finite(value)){const marker=x+clamp((shown-bounds.min)/(bounds.max-bounds.min),0,1)*barW;ctx.beginPath();ctx.moveTo(marker,y-7);ctx.lineTo(marker-5,y-1);ctx.lineTo(marker+5,y-1);ctx.closePath();ctx.fillStyle='#30243e';ctx.fill();}
    ctx.font='15px Arial';ctx.fillStyle='#51425f';bounds.ticks.forEach((tick,j)=>{ctx.textAlign=j===0?'left':j===4?'right':'center';ctx.fillText((['elevation','posterior_elevation'].includes(state.color)&&tick>0?'+':'')+(Number.isInteger(tick)?tick:tick.toFixed(1)),x+j*barW/4,y+36);});ctx.textAlign='left';y+=60;
    ctx.fillText('Gray: unavailable · stripes: estimate · crosshatch: color uncertain',x,y);y+=27;
    const coverage=info.mapCoverage;if(coverage){ctx.font='14px Arial';const u=coverage.uncertain??coverage.clipped??0;for(const line of wrap(ctx,(state.mapView?'Full map circle':'Supported surface map')+' · '+(approx?'Report support ':'Source ')+coveragePercent(coverage.source,coverage.total)+' · Estimated '+coveragePercent(coverage.estimated,coverage.total)+' · Color uncertain '+coveragePercent(u,coverage.total)+' · Unavailable '+coveragePercent(coverage.unavailable-u,coverage.total),panel)){ctx.fillText(line,x,y);y+=21;}ctx.fillText('Narrow-gap estimates '+(state.estimates?'on':'off')+' · coverage is not accuracy',x,y);y+=23;}
    if(info.displaySample?.status===2){ctx.fillText('Estimated display value at selected point: '+numeric(info.displaySample.value,state.color,true),x,y);y+=23;}
    if(info.displayStatus?.status===3){ctx.fillText('Selected report color is uncertain; no exact value assigned.',x,y);y+=23;}
    if(state.mapView){ctx.fillText('2D map projection · surface height '+(info.selectedHasSurface?'available separately':'unavailable at selected XY'),x,y);y+=23;}
   }
   ctx.font='15px Arial';if(info.thinnest&&info.selectionKind!=='minimum'){ctx.fillText(info.minimumLabel+': '+numeric(info.thinnest.thickness,'thickness',approx),x,y);y+=25;}
   for(const line of wrap(ctx,[(!info.selectedHasSurface&&q?'Selected point only: surrounding surface patch unavailable.':''),(reportFor(eye)?.scan_quality==='warning'?'Source quality warning.':''),...(s?.sourceNotes||[])].filter(Boolean).join(' '),panel).slice(0,3)){ctx.fillText(line,x,y);y+=22;}
  });
  ctx.fillStyle='#64586d';ctx.font='17px Arial';const footer='Report-image reconstructions and minima remain approximate. Full 2D maps preserve available XY data independently of surface geometry. Striped estimates never replace original measurements or minima. Crosshatched report colors are uncertain; their preview colors do not establish exact values. Unavailable surface heights remain unavailable. Iris, globe and peripheral anatomy are illustrative.';let y=out.height-102;for(const line of wrap(ctx,footer,width-pad*2)){ctx.fillText(line,pad,y);y+=24;}
  if(download){const a=document.createElement('a');a.download='NKPI_OD_OS_'+state.visit+'_integrated_v913.png';a.href=out.toDataURL('image/png');a.click();}return out;
 }
 function click(event){const b=event.target.closest('button');if(!b||b.disabled)return;if(b.dataset.ieVisit)setVisit(b.dataset.ieVisit);else if(b.dataset.ieMode)setState({section:b.dataset.ieMode==='section'});else if(b.dataset.ieView)setState({view:b.dataset.ieView});else if(b.dataset.ieZoom)setState({zoom:state.zoom*(b.dataset.ieZoom==='in'?1.15:1/1.15)});else if(b.hasAttribute('data-ie-thinnest'))views[b.closest('[data-ie-eye]')?.dataset.ieEye]?.selectThinnest();else if(b.hasAttribute('data-ie-save'))exportFigure();else if(b.hasAttribute('data-ie-change'))options.onRequestChange?.();}
 function change(event){if(event.target.hasAttribute('data-ie-field'))setState({color:event.target.value});else if(event.target.hasAttribute('data-ie-contours'))setState({contours:event.target.checked});else if(event.target.hasAttribute('data-ie-estimates'))setState({estimates:event.target.checked});}
 root.addEventListener('click',click);root.addEventListener('change',change);const resizeObserver=new ResizeObserver(resizeAll);resizeObserver.observe(root.querySelector('.ie-eyes'));
 renderVisit();
 const dispose=()=>{if(dead)return;dead=true;resizeObserver.disconnect();root.removeEventListener('click',click);root.removeEventListener('change',change);for(const eye of EYES)views[eye]?.dispose();delete host.__integratedEye;};
 dispose.getState=()=>({...state,cut:state.section,hasData:EYES.some(e=>views[e]?.getInfo().hasData)});dispose.getInfo=()=>EYES.map(e=>views[e]?.getInfo());dispose.getViews=()=>EYES.map(e=>views[e]);dispose.setState=setState;dispose.setVisit=setVisit;dispose.exportFigure=exportFigure;dispose.draw=drawAll;
 host.__integratedEye=dispose;return dispose;
}
global.NKPIIntegratedEye={mount,LAYERS};
})(typeof window!=='undefined'?window:globalThis);
