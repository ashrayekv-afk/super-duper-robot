/* Integrated patient geometry for the clinical viewer.
 * Image colors are estimates. Uncertain color intervals cannot supply accepted heights.
 * Source reports remain immutable; this adapter only prepares presentation.
 */
(function(root){'use strict';
const node=typeof module!=='undefined'&&module.exports;
const I=node?require('../image_regions.js'):root.NKPIImageRegions;
const S=node?require('./patient_shape.js'):root.NKPIPatientShape;
const FIELDS=['thickness','anterior','posterior','elevation','posterior_elevation'];
const finite=Number.isFinite;
const copy=value=>typeof structuredClone==='function'?structuredClone(value):JSON.parse(JSON.stringify(value));

function calibration(field,key){
 const provenance=field?.legend_provenance;
 const anchors=key==='elevation_um'?provenance?.anchors:field?.legend?.anchors;
 const values=(anchors||[]).map(p=>p.value).filter(finite);
 const declared=provenance?.calibrated_range_um||provenance?.range_um;
 if(key==='elevation_um'&&Array.isArray(declared)&&declared.length===2&&declared.every(finite)&&declared[0]<declared[1]){
  if(values.length&&[Math.min(...values),Math.max(...values)].some((x,i)=>Math.abs(x-declared[i])>1e-8))return null;
  return [...declared];
 }
 return values.length>=2&&Math.min(...values)<Math.max(...values)?[Math.min(...values),Math.max(...values)]:null;
}
function censor(field,key,bounds=calibration(field,key)){
 const out=copy(field),masks={},counts={};
 if(!bounds)return {field:out,masks,counts,bounds:null};
 for(const level of ['central','full']){
  const target=level==='full'?out.full_display:out;if(!target)continue;
  const grid=target[key],n=grid.length,c=(n-1)/2;
  const mask=grid.map(row=>row.map(v=>!!v&&(v.lo<=bounds[0]||v.hi>=bounds[1])));
  let total=0,available=0,removed=0;
  for(let j=0;j<n;j++)for(let i=0;i<n;i++){
   if(Math.hypot(i-c,j-c)<=c+1e-8)total++;
   if(mask[j][i]){grid[j][i]=null;removed++;}
   if(grid[j][i])available++;
  }
  target.coverage=total?available/total:0;masks[level]=mask;counts[level]={removed,remaining:available};
 }
 return {field:out,masks,counts,bounds:[...bounds]};
}
function gridInfo(field,key,full=true){
 const selected=full&&field.full_display?field.full_display:field;
 const grid=selected[key],n=grid.length,center=(n-1)/2,radius=field.diameter_mm*(selected===field?field.extent:1)/2;
 return {grid,n,center,radius,step:radius/center,full:selected!==field};
}
function sampleSupported(field,key,x,y){
 const g=gridInfo(field,key),u=x/g.step+g.center,v=-y/g.step+g.center;
 if(Math.hypot(x,y)>g.radius+1e-8||u<0||v<0||u>g.n-1||v>g.n-1)return null;
 const i=Math.min(g.n-2,Math.floor(u)),j=Math.min(g.n-2,Math.floor(v)),fx=u-i,fy=v-j;
 const cells=[[i,j,(1-fx)*(1-fy)],[i+1,j,fx*(1-fy)],[i,j+1,(1-fx)*fy],[i+1,j+1,fx*fy]].filter(p=>p[2]>1e-8);
 return cells.every(([a,b])=>finite(g.grid[b][a]?.value))?cells.reduce((s,[a,b,w])=>s+g.grid[b][a].value*w,0):null;
}
function maskedAt(masked,key,x,y,full=true){
 if(!masked)return false;
 const g=gridInfo(masked.field,key,full),mask=masked.masks[g.full?'full':'central'];
 if(!mask||Math.hypot(x,y)>g.radius+1e-8)return false;
 return !!mask[Math.round(-y/g.step+g.center)]?.[Math.round(x/g.step+g.center)];
}
function supportedCellTriangles(model){
 const triangles=model.triangles.filter(ids=>ids.every(k=>model.vertices[k]));
 // A fixed diagonal can discard a whole cell when one of its diagonal
 // corners is absent. Retain the triangle between the other three original
 // corners, without adding a vertex, crossing a cell, or filling its missing
 // corner. Native topology and cells with all four corners stay unchanged.
 if(model.kind!=='estimated'||model.mapSource!=='image')return triangles;
 const {nx,ny,vertices}=model;
 if(!Number.isInteger(nx)||!Number.isInteger(ny)||nx<2||ny<2||vertices.length!==nx*ny)return triangles;
 const key=ids=>[...ids].sort((a,b)=>a-b).join(','),known=new Set(triangles.map(key));
 for(let j=0;j<ny-1;j++)for(let i=0;i<nx-1;i++){
  const a=j*nx+i,b=a+1,c=a+nx,d=c+1;
  const ids=!vertices[b]&&vertices[a]&&vertices[c]&&vertices[d]?[a,d,c]:
   !vertices[c]&&vertices[a]&&vertices[b]&&vertices[d]?[a,b,d]:null;
  if(ids&&!known.has(key(ids))){triangles.push(ids);known.add(key(ids));}
 }
 return triangles;
}
function finish(model){
 model.triangles=supportedCellTriangles(model);
 if(!model.triangles.length)throw Error('No complete supported surface cells remain.');
 const valid=model.vertices.filter(Boolean),thickness=valid.filter(v=>finite(v.thickness)).map(v=>v.thickness);
 model.coverage=model.possible?valid.length/model.possible:0;
 model.interpolated=valid.filter(v=>v.interpolated).length;
 model.centerZ=valid.reduce((n,v)=>n+v.front[2],0)/valid.length;
 model.thicknessRange=thickness.length?[Math.min(...thickness),Math.max(...thickness)]:null;
 return S.prepare(model);
}
// Global coverage decides whether to accept a complete reconstruction. A
// partial view may still display locally supported patches, with the original
// rejection retained. Local fitting, nearest support and mm axes are unchanged.
function partialPatches(shape,thickness,aperture,reason){
 const g=gridInfo(shape,'elevation_um',aperture.fullDisplayUsed),n=g.n,c=g.center,R=shape.bfs_radius_mm;
 const tg=thickness?gridInfo(thickness,'grid',aperture.fullDisplayUsed):null,vertices=[];let possible=0;
 for(let j=0;j<n;j++)for(let i=0;i<n;i++){
  const x=(i-c)*g.step,y=(j-c)*g.step;
  if(Math.hypot(x,y)>g.radius+1e-8){vertices.push(null);continue;}possible++;
  const e=S.smooth(g.grid,i,j,g.step);
  if(!e||R*R<=x*x+y*y){vertices.push(null);continue;}
  let t=null;
  if(tg&&Math.hypot(x,y)<=tg.radius+1e-8){
   const u=x/tg.step+tg.center,v=y/tg.step+tg.center;
   if(u>=0&&v>=0&&u<=tg.n-1&&v<=tg.n-1)t=S.smooth(tg.grid,Math.round(u),Math.round(v),tg.step);
  }
  const q=Math.sqrt(R*R-x*x-y*y),dx=-x/q+e.dx/1000,dy=y/q-e.dy/1000,den=Math.hypot(dx,dy,1),normal=[-dx/den,-dy/den,1/den];
  const front=[x,-y,q-R+e.value/1000],tv=t&&t.value>=100&&t.value<=1200?t.value:null;
  vertices.push({front,back:finite(tv)?front.map((v,k)=>v-normal[k]*tv/1000):null,thickness:tv,elevation:e.value,
   posterior_elevation:null,interpolated:e.interpolated||!!(finite(tv)&&t.interpolated)});
 }
 const triangles=[];
 for(let j=0;j<n-1;j++)for(let i=0;i<n-1;i++){
  const a=j*n+i,b=a+1,c=a+n,d=c+1;
  for(const ids of [[a,b,c],[b,d,c]])if(ids.every(k=>vertices[k]))triangles.push(ids);
 }
 return finish({vertices,triangles,nx:n,ny:n,axisX:Array.from({length:n},(_,i)=>(i-c)*g.step),axisY:Array.from({length:n},(_,j)=>(c-j)*g.step),
  kind:'estimated',mapSource:'image',mapDefinitions:{},radius:g.radius,bfs:R,fit_diameter:shape.fit_diameter_mm,
  fullDisplayUsed:g.full,possible,partial:true,rejectedCompleteReason:reason,complete_reconstruction_rejected:reason});
}
function annotate(model,report,notes=[]){
 model.eye=report.eye;model.visit=report.visit;
 model.sourceKind=model.kind==='native'?'native':model.kind==='estimated'?'report-image':'reference';
 model.hasPatientGeometry=model.kind!=='reference';
 model.partial=!!model.partial;
 model.sourceLabel=model.kind==='native'?'Native surface coordinates':model.kind==='reference'?'Reference anatomy · patient heights unavailable':model.partial?'Partial report-image reconstruction':'Report-image approximation';
 model.sourceNotes=notes;
 model.availableFields=FIELDS.filter(f=>model.vertices.some(v=>finite(v?.[f])));
 model.innerBoundaryKind=model.vertices.some(v=>v?.back)?model.kind==='native'?'native':model.kind==='estimated'?'thickness-derived':'reference':'unavailable';
 model.fieldSummary=Object.fromEntries(FIELDS.map(f=>{
  const values=model.vertices.flatMap(v=>finite(v?.[f])?[v[f]]:[]);
  return [f,{count:values.length,min:values.length?Math.min(...values):null,max:values.length?Math.max(...values):null}];
 }));
 // Independent display samples retain the original map's physical grid and
 // calibration-uncertainty mask. They never replace a vertex or point reading.
 model.displayMaps=displayMapsFor(report);
 return model;
}
function displayDescriptor(map,field,key,bounds=calibration(map,key)){
 if(!map||!bounds)return null;
 let selected=map.full_display||map,detail=map.full_display?'full-map-grid':'central-map-grid';
 if(map.display_detail&&typeof I.validateDetailGrid==='function'){
  try{I.validateDetailGrid(map.display_detail,map,key);selected=map.display_detail;detail='original-map-detail';}catch(_){/* An invalid optional texture cannot overwrite accepted source grids. */}
 }
 const grid=selected[key],height=grid?.length,width=grid?.[0]?.length;
 if(!height||height!==width||grid.some(row=>!Array.isArray(row)||row.length!==width))return null;
 const radius=map.diameter_mm*(selected===map?map.extent:1)/2;
 if(!finite(radius)||radius<=0)return null;
 const axisX=Array.from({length:width},(_,i)=>-radius+2*radius*i/(width-1)),axisY=Array.from({length:height},(_,j)=>-radius+2*radius*j/(height-1));
 const values=[],status=[],sampling=[],intervalWidths=[],previewValues=[],uncertaintyKind=[];
 // Report rows increase downwards; all display textures increase in +y.
 for(let j=0;j<height;j++)for(let i=0;i<width;i++){
  const raw=grid[height-1-j][i],inside=Math.hypot(axisX[i],axisY[j])<=radius+1e-8;
  let value=null,flag=0,widthUm=null,method=null,preview=null,uncertainty=null;
  if(inside&&raw&&[raw.value,raw.lo,raw.hi].every(finite)){
   if(raw.lo<=bounds[0]||raw.hi>=bounds[1]){
    flag=3;
    // The decoded center is only a report-color preview. An interval touching
    // a calibration endpoint does not prove saturation or a numerical bound.
    // Keep it out of accepted values, source readings and surface geometry.
    const center=key==='elevation_um'?raw:I.canonicalValue({value:raw.value,lo:raw.value,hi:raw.value},field,map.unit);
    if(center&&finite(center.value)&&(field!=='thickness'||center.value>0))preview=center.value;
    uncertainty=bounds.some(bound=>Math.abs(raw.value-bound)<=1e-8)?'endpoint':'ambiguous';
   }
   else{
    const converted=key==='elevation_um'?raw:I.canonicalValue(raw,field,map.unit);
    if(converted&&finite(converted.value)&&(field!=='thickness'||converted.value>0)){
     value=converted.value;flag=1;widthUm=Math.max(0,converted.hi-converted.lo);method=raw.sampling||'unknown';
    }
   }
  }
  values.push(value);status.push(flag);sampling.push(method);intervalWidths.push(widthUm);previewValues.push(preview);uncertaintyKind.push(uncertainty);
 }
 return {schema:'nkpi-integrated-display-map-1',field,width,height,xMin:-radius,xMax:radius,yMin:-radius,yMax:radius,
  axisX,axisY,radius_mm:radius,values,status,sampling,intervalWidths,previewValues,uncertaintyKind,sourceKind:'report-image',detail};
}
function displayMapsFor(report){
 const out={};if(report.surface?.kind==='measured')return out;
 for(const field of ['anterior','posterior','thickness']){
  const candidates=(report.image_maps||[]).filter(map=>map.id===field);if(candidates.length!==1)continue;
  const descriptor=displayDescriptor(candidates[0],field,'grid');if(descriptor)out[field]=descriptor;
 }
 const shape=report.shape_estimate;
 if(shape){
  const descriptor=displayDescriptor(shape,'elevation','elevation_um');if(descriptor)out.elevation=descriptor;
  if(shape.posterior_elevation){const back=displayDescriptor(shape.posterior_elevation,'posterior_elevation','elevation_um');if(back)out.posterior_elevation=back;}
 }
 return out;
}
function reference(report,maps,notes,reason){
 const model=S.referenceModel(maps);model.referenceReason=reason;notes.push(reason);
 return annotate(model,report,notes);
}
function fromReport(report){
 if(!report)throw Error('No report is linked to this visit.');
 if(!['OD','OS'].includes(report.eye)||!['first','latest'].includes(report.visit))throw Error('A confirmed eye and visit are required.');
 if(report.surface?.kind==='measured'){
  const model=S.fromReport(report),notes=model.kind==='reference'?[model.referenceReason]:['Native surface heights and device pachymetry retain their supplied values and coordinate definitions.'];
  return annotate(model,report,notes);
 }
 const notes=[],inputMaps=report.image_maps||[],maskedMaps=[];
 for(const id of ['anterior','posterior','thickness']){
  const candidates=inputMaps.filter(m=>m.id===id);
  if(candidates.length>1){notes.push('Multiple '+id+' maps are linked; that field is unavailable.');continue;}
  if(!candidates.length)continue;
  I.validateMap(candidates[0]);const masked=censor(candidates[0],'grid');
  if(!masked.bounds){notes.push('The '+id+' map lacks its accepted legend calibration and is unavailable.');continue;}
  maskedMaps.push({id,...masked});
 }
 const maps=maskedMaps.map(x=>x.field),originalShape=report.shape_estimate;
 if(!originalShape)return reference(report,maps,notes,report.shape_issue||'Anterior surface heights or usable elevation are unavailable.');
 I.validateShape(originalShape);
 const bounds=calibration(originalShape,'elevation_um');
 if(!bounds)return reference(report,maps,notes,'The elevation legend calibration is unavailable. Re-import the original report to calibrate its surface colors.');
 const shapeMask=censor(originalShape,'elevation_um',bounds),shape=shapeMask.field;
 // Posterior elevation is an independent x/y attribute, not absolute back z.
 const originalPosterior=originalShape.posterior_elevation;
 const posteriorBounds=originalPosterior?calibration(originalPosterior,'elevation_um')||bounds:null;
 const posteriorMask=originalPosterior?censor(originalPosterior,'elevation_um',posteriorBounds):null;
 delete shape.posterior_elevation;
 const thicknessMasked=maskedMaps.find(x=>x.id==='thickness');
 let thickness=thicknessMasked?.field||null;
 if(thickness&&Math.abs(thickness.diameter_mm-shape.diameter_mm)>1e-8){
  notes.push('Thickness and elevation plot diameters differ; the inner boundary is unavailable.');thickness=null;
 }
 let model;
 try{model=S.addImageOverlays(S.imageModel(shape,thickness),maps);}
 catch(error){
  if(!/coverage|Insufficient elevation/.test(error.message))return reference(report,maps,notes,error.message);
  // Select the same accepted aperture as the original uncensored source. No
  // smaller field is stretched to cover the iris or the full printed plot.
  let aperture;
  try{const cleanOriginal=copy(originalShape);delete cleanOriginal.posterior_elevation;aperture=S.imageModel(cleanOriginal,null);}
  catch(_){return reference(report,maps,notes,error.message);}
  try{model=S.addImageOverlays(partialPatches(shape,thickness,aperture,error.message),maps);}
  catch(_){return reference(report,maps,notes,'Too little local elevation support remains for a surface patch.');}
 }
 const level=model.fullDisplayUsed?'full':'central';let censoredGeometry=0,censoredThickness=0;
 for(let k=0;k<model.vertices.length;k++){
  const v=model.vertices[k];if(!v)continue;
  if(shapeMask.masks[level]?.[Math.floor(k/model.nx)]?.[k%model.nx]){model.vertices[k]=null;censoredGeometry++;continue;}
  if(thickness&&maskedAt(thicknessMasked,'grid',v.front[0],v.front[1],model.fullDisplayUsed)){
   v.back=null;v.thickness=null;censoredThickness++;
  }
  if(posteriorMask)v.posterior_elevation=sampleSupported(posteriorMask.field,'elevation_um',v.front[0],v.front[1]);
 }
 if(posteriorMask){
  model.posteriorBfs=posteriorMask.field.bfs_radius_mm;
  const sparse=posteriorMask.counts.central.remaining<440;
  model.mapDefinitions.posterior_elevation={type:'best_fit_sphere',reference:'independent_posterior_float_bfs',fit_diameter_mm:posteriorMask.field.fit_diameter_mm,partial:sparse};
  if(sparse)notes.push('Posterior elevation has sparse accepted support; only supported point attributes are shown.');
 }
 try{finish(model);}catch(error){return reference(report,maps,notes,error.message);}
 if(model.coverage<.5){model.partial=true;model.rejectedCompleteReason=model.rejectedCompleteReason||'Less than half of the reconstruction field has usable elevation support.';}
 model.endpointCensoring={applied:true,calibrated_elevation_range_um:bounds,censoredGeometry,censoredThickness,
  anterior:shapeMask.counts,posterior:posteriorMask?.counts||null,maps:Object.fromEntries(maskedMaps.map(m=>[m.id,m.counts]))};
 notes.push('Printed elevation and a centered, untilted reference sphere approximate the front surface.');
 notes.push('Color intervals touching the calibration limits and unsupported regions remain unavailable for numerical reconstruction.');
 if(model.vertices.some(v=>v?.back))notes.push('The inner boundary is offset along the reconstructed front normal by retained pachymetry.');
 if(model.partial)notes.push('Only supported patches are displayed; complete reconstruction was not accepted.');
 return annotate(model,report,notes);
}
const api={fromReport,calibration,censor,sampleSupported,partialPatches,supportedCellTriangles,displayDescriptor,displayMapsFor,FIELDS};
if(node)module.exports=api;else root.NKPIIntegratedModel=api;
})(typeof window!=='undefined'?window:globalThis);
