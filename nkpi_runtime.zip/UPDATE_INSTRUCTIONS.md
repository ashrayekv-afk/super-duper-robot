# Install version 9.0.9

Download **NKPI_v909_GitHub_Upload.zip** and extract the outer download once.

Upload the four top-level files to the existing GitHub repository root: `kcn_dual_calculator_app.py`, `nkpi_runtime.zip`, `requirements.txt` and `README.md`. Preserve `.streamlit/config.toml` as the fifth file. Replace matching files and keep the inner runtime ZIP intact.

Keep **kcn_dual_calculator_app.py** as Streamlit's main file and **Python 3.12** as the runtime. Reboot the app and refresh. Confirm **9.0.9-bilateral-eye** in the footer.

Reimport the original report ZIPs, verify the source measurements and calculate. This generates full printed-map display samples for supported layouts. Open **3D corneal view · Both eyes**. OD and OS appear together, with shared map controls and linked rotation/zoom. Choose **Curvature + thickness**, another map, **Surface shape** or **Natural eye**. Save both eyes produces one figure. Regional changes and cone tracking remain below in a collapsed comparison section.

The observed-change/evidence drawer and demo-eye/sample controls have been removed. True physical scale remains the default. Optional report-image relief is explicitly labeled, and missing measurements remain unavailable. The surrounding globe and iris are reference anatomy.

No extra application folders or API key are needed. Upload the launcher and matching runtime ZIP together if a bundle error appears; do not rename them or place them inside an extra folder.
