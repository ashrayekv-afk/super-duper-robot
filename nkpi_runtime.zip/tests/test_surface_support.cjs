'use strict';
// Engineering regressions for source topology and uncertain report colors.
// No patient report or device-level accuracy assertion is embedded here.
const assert=require('node:assert/strict');
const M=require('../components/cornea/integrated_model.js');
const S=require('../components/cornea/patient_shape.js');
const P=require('../components/cornea/integrated_measurements.js');
let count=0;
const test=(name,fn)=>{fn();count++;console.log('PASS '+name);};
const clone=value=>structuredClone(value);
const key=ids=>[...ids].sort((a,b)=>a-b).join(',');
const freeze=value=>{if(value&&typeof value==='object'){Object.freeze(value);Object.values(value).forEach(freeze);}return value;};
function gridModel(nx,ny,present,kind='estimated'){
 const vertices=Array.from({length:nx*ny},(_,k)=>present(k)?{
  front:[(k%nx)*.15,-Math.floor(k/nx)*.15,k*.001],back:[(k%nx)*.15,-Math.floor(k/nx)*.15,k*.001-.47],
  thickness:470+k,anterior:44+k*.1,posterior:-7-k*.01,elevation:k,posterior_elevation:-k,interpolated:false
 }:null);
 const triangles=[];
 for(let j=0;j<ny-1;j++)for(let i=0;i<nx-1;i++){
  const a=j*nx+i,b=a+1,c=a+nx,d=c+1;
  for(const ids of [[a,b,c],[b,d,c]])if(ids.every(k=>vertices[k]))triangles.push(ids);
 }
 return {vertices,triangles,nx,ny,kind,mapSource:kind==='native'?'native':'image'};
}
test('Every four-corner presence pattern retains exactly its supported cell triangles',()=>{
 for(let mask=0;mask<16;mask++){
  const m=gridModel(2,2,k=>!!(mask&(1<<k))),before=clone(m),result=M.supportedCellTriangles(freeze(m));
  const available=before.vertices.filter(Boolean).length;
  assert.equal(result.length,available===4?2:available===3?1:0,'corner mask '+mask);
  assert.equal(new Set(result.map(key)).size,result.length);
  assert(result.every(ids=>ids.length===3&&ids.every(k=>before.vertices[k])));
  assert.deepEqual(m,before,'source mutation for corner mask '+mask);
  if(available===3)assert.deepEqual([...result[0]].sort((a,b)=>a-b),before.vertices.flatMap((v,k)=>v?[k]:[]));
  if(available===4)assert.deepEqual(result,before.triangles);
 }
});
test('Added triangles retain original vertex identity and are idempotent',()=>{
 const m=gridModel(2,2,k=>k!==1),before=clone(m.vertices),refs=m.vertices.slice();
 const first=M.supportedCellTriangles(m),second=M.supportedCellTriangles({...m,triangles:first});
 assert.deepEqual(first,[[0,3,2]]);assert.deepEqual(second,first);assert.deepEqual(m.vertices,before);
 refs.forEach((v,k)=>assert.equal(m.vertices[k],v));
});
test('Adaptive cells do not bridge absent corners, multiple cells or broad holes',()=>{
 const absent=new Set([6,7,11,12,18]),m=gridModel(5,5,k=>!absent.has(k)),before=clone(m),triangles=M.supportedCellTriangles(freeze(m));
 assert(triangles.length>before.triangles.length);
 for(const ids of triangles){
  assert(ids.every(k=>before.vertices[k]));
  const xs=ids.map(k=>k%5),ys=ids.map(k=>Math.floor(k/5));
  assert.equal(Math.max(...xs)-Math.min(...xs),1);assert.equal(Math.max(...ys)-Math.min(...ys),1);
 }
 assert.equal(new Set(triangles.map(key)).size,triangles.length);assert.deepEqual(m,before);
 const byCell=new Map();for(const ids of triangles){const cell=Math.min(...ids.map(k=>Math.floor(k/5)))*5+Math.min(...ids.map(k=>k%5));byCell.set(cell,(byCell.get(cell)||0)+1);}
 for(const [cell,n]of byCell){const corners=[cell,cell+1,cell+5,cell+6],valid=corners.filter(k=>before.vertices[k]).length;assert.equal(n,valid===4?2:1);}
});
test('Native coordinates, native holes and native topology are unchanged',()=>{
 const native=gridModel(2,2,k=>k!==1,'native');assert.deepEqual(M.supportedCellTriangles(native),native.triangles);
 const axis=[-1,-.5,0,.5,1],make=fn=>axis.map((y,j)=>axis.map((x,i)=>fn(x,y,i,j))),surface={schema:'nkpi-corneal-surface-1',kind:'measured',source:'device_numeric_export',eye:'OD',visit:'latest',
  units:{xy:'mm',z:'mm',elevation:'um',thickness:'um',curvature:'D'},coordinate_system:{origin:'corneal_vertex',x_positive:'nasal',y_positive:'superior',z_positive:'anterior'},x_mm:axis,y_mm:axis,
  anterior:{z_mm:make((x,y,i,j)=>i===2&&j===2?null:-.1*(x*x+y*y)),curvature_D:make(()=>47),curvature_type:'axial'},
  posterior:{z_mm:make((x,y)=>-.1*(x*x+y*y)-.6)},thickness_um:make(()=>480),thickness_definition:'device_pachymetry'};
 const report={eye:'OD',visit:'latest',surface},before=clone(report),expected=S.fromReport(report),actual=M.fromReport(freeze(report));
 assert.deepEqual(actual.vertices,expected.vertices);assert.deepEqual(actual.triangles,expected.triangles);
 assert.deepEqual(P.findThinnest(actual),P.findThinnest(expected));assert.deepEqual(report,before);
});
function descriptorMap(unit='µm',bounds=[300,900]){
 return {unit,diameter_mm:9,extent:2/3,grid:Array.from({length:5},()=>Array.from({length:5},()=>({value:500,lo:490,hi:510,sampling:'direct'}))),legend:{anchors:bounds.map(value=>({value}))}};
}
test('Endpoint and overlapping-interval previews remain outside accepted quantitative values',()=>{
 const map=descriptorMap();map.grid[2][2]={value:300,lo:300,hi:305,sampling:'direct'};
 map.grid[1][2]={value:500,lo:300,hi:510,sampling:'local_color'};
 map.grid[3][2]={value:900,lo:895,hi:900,sampling:'direct'};
 map.grid[2][1]=null;const before=clone(map),d=M.displayDescriptor(freeze(map),'thickness','grid');
 const at=(row,column)=>(4-row)*5+column;
 for(const [row,column,value,kind]of [[2,2,300,'endpoint'],[1,2,500,'ambiguous'],[3,2,900,'endpoint']]){
  const k=at(row,column);assert.equal(d.status[k],3);assert.equal(d.values[k],null);assert.equal(d.previewValues[k],value);assert.equal(d.uncertaintyKind[k],kind);
  assert.equal(d.sampling[k],null);assert.equal(d.intervalWidths[k],null);
 }
 assert.equal(d.status[at(2,1)],0);assert.equal(d.previewValues[at(2,1)],null);assert.equal(d.uncertaintyKind[at(2,1)],null);
 assert.equal(d.status[at(2,3)],1);assert.equal(d.values[at(2,3)],500);assert.equal(d.previewValues[at(2,3)],null);assert.equal(d.uncertaintyKind[at(2,3)],null);
 assert.deepEqual(map,before);
});
test('Uncertain curvature previews use the same units while preserving endpoint versus ambiguity',()=>{
 for(const field of ['anterior','posterior']){
  const map=descriptorMap('mm',[4,12]);map.grid=map.grid.map(row=>row.map(()=>({value:7,lo:6.5,hi:7.5,sampling:'direct'})));
  map.grid[2][2]={value:4,lo:4,hi:4.2,sampling:'direct'};map.grid[1][2]={value:5,lo:4,hi:5.5,sampling:'local_color'};
  const d=M.displayDescriptor(map,field,'grid'),factor=field==='anterior'?337.5:40;
  assert.equal(d.previewValues[12],factor/4);assert.equal(d.uncertaintyKind[12],'endpoint');assert.equal(d.values[12],null);
  assert.equal(d.previewValues[17],factor/5);assert.equal(d.uncertaintyKind[17],'ambiguous');assert.equal(d.values[17],null);
 }
 const map=descriptorMap('D',[-12,-2]);map.grid[2][2]={value:-12,lo:-12,hi:-11,sampling:'direct'};
 const d=M.displayDescriptor(map,'posterior','grid');assert.equal(d.previewValues[12],12);assert.equal(d.values[12],null);
});
test('Signed elevation previews retain signs without manufacturing a saturation bound',()=>{
 const map={diameter_mm:9,extent:2/3,elevation_um:Array.from({length:5},()=>Array.from({length:5},()=>({value:0,lo:-2,hi:2,sampling:'direct'}))),legend_provenance:{anchors:[{value:-75},{value:75}],calibrated_range_um:[-75,75]}};
 map.elevation_um[2][2]={value:-75,lo:-75,hi:-70,sampling:'direct'};
 map.elevation_um[1][2]={value:20,lo:-75,hi:25,sampling:'local_color'};
 const d=M.displayDescriptor(map,'elevation','elevation_um');
 assert.equal(d.previewValues[12],-75);assert.equal(d.uncertaintyKind[12],'endpoint');assert.equal(d.values[12],null);
 assert.equal(d.previewValues[17],20);assert.equal(d.uncertaintyKind[17],'ambiguous');assert.equal(d.values[17],null);
});

// Optional release regression against local, unbundled original report inputs.
// The public package contains no patient data. Set both paths to exercise it.
if(process.env.NKPI_PREVIOUS_MODEL||process.env.NKPI_REPORT_FIXTURES){
 assert(process.env.NKPI_PREVIOUS_MODEL&&process.env.NKPI_REPORT_FIXTURES,'Both regression paths are required.');
 const fs=require('node:fs'),path=require('node:path'),beforeModel=require(path.resolve(process.env.NKPI_PREVIOUS_MODEL));
 const extracted=JSON.parse(fs.readFileSync(process.env.NKPI_REPORT_FIXTURES,'utf8'));
 const expectedAdditions=process.env.NKPI_EXPECTED_SURFACE_ADDITIONS?JSON.parse(process.env.NKPI_EXPECTED_SURFACE_ADDITIONS):null;
 for(const eye of ['OD','OS'])test(eye+' original report retains coordinates, fields, coverage and minimum with only supported triangles added',()=>{
  const pages=extracted.pages.filter(page=>page.eye===eye),shapePage=pages.find(page=>page.shape);
  assert(shapePage,'A source shape is required for this release regression.');
  const report={eye,visit:'latest',image_maps:pages.flatMap(page=>page.maps||[]),shape_estimate:shapePage.shape},input=clone(report),old=beforeModel.fromReport(report),next=M.fromReport(freeze(report));
  const dataVertex=v=>v&&Object.fromEntries(Object.entries(v).filter(([name])=>!['frontNormal','backNormal'].includes(name)));
  assert.deepEqual(next.vertices.map(dataVertex),old.vertices.map(dataVertex));
  for(const field of ['radius','nx','ny','axisX','axisY','coverage','fieldSummary','endpointCensoring','thicknessRange','fullDisplayUsed','availableFields'])assert.deepEqual(next[field],old[field],field+' changed');
  assert.deepEqual(P.findThinnest(next),P.findThinnest(old));assert.deepEqual(report,input);
  const oldKeys=new Set(old.triangles.map(key)),nextKeys=new Set(next.triangles.map(key));assert([...oldKeys].every(k=>nextKeys.has(k)));
  const added=next.triangles.filter(ids=>!oldKeys.has(key(ids)));
  for(const ids of added){
   assert(ids.every(k=>old.vertices[k]));const xs=ids.map(k=>k%old.nx),ys=ids.map(k=>Math.floor(k/old.nx));
   assert.equal(Math.max(...xs)-Math.min(...xs),1);assert.equal(Math.max(...ys)-Math.min(...ys),1);
  }
  if(expectedAdditions)assert.equal(added.length,expectedAdditions[eye]);
  console.log('  '+JSON.stringify({eye,oldTriangles:old.triangles.length,newTriangles:next.triangles.length,addedTriangles:added.length,sourceCoverage:next.coverage,minimum:P.findThinnest(next)}));
 });
}
console.log(`${count} surface-support checks passed.`);
