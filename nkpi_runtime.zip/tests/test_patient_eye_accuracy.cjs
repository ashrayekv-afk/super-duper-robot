'use strict';
// Acceptance checks for the source-to-eye contract. All inputs are mathematical
// fixtures; these verify numerical/display behavior, not clinical validity.
const assert = require('node:assert/strict');
const {test} = require('node:test');
const Shape = require('../components/cornea/patient_shape.js');
const Inspect = require('../components/cornea/shape_inspection.js');
const Schema = require('../components/cornea/surface_schema.js');
const near = (a, b, tolerance = 1e-9) => assert.ok(Number.isFinite(a) && Number.isFinite(b) && Math.abs(a - b) <= tolerance, `${a} != ${b}`);
const distance = (a, b) => Math.hypot(...a.map((v, i) => v - b[i]));
const fields = ['thickness', 'anterior', 'posterior', 'elevation', 'posterior_elevation'];

function nativeFixture(options = {}) {
  const x = options.x || [-3, -2, -1, 0, 1, 2, 3];
  const y = options.y || [-3, -2, -1, 0, 1, 2, 3];
  const radius = Math.min(6, Math.max(...x.map(Math.abs)), Math.max(...y.map(Math.abs)));
  const g = fn => y.map(yy => x.map(xx => Math.hypot(xx, yy) <= radius + 1e-9 ? fn(xx, yy) : null));
  const zSign = options.z_positive === 'posterior' ? -1 : 1;
  const front = (xx, yy) => 1.9 - .065 * (xx * xx + yy * yy) + .023 * xx + .011 * yy;
  const data = {
    schema: options.mapsOnly ? 'nkpi-corneal-maps-1' : 'nkpi-corneal-surface-1',
    kind: 'measured', source: 'device_numeric_export', eye: options.eye || 'OS', visit: 'latest',
    units: {xy: 'mm', z: 'mm', elevation: 'um', thickness: 'um', curvature: 'D'},
    coordinate_system: {origin: 'corneal_vertex', x_positive: options.x_positive || 'temporal',
      y_positive: options.y_positive || 'superior', z_positive: options.z_positive || 'anterior'},
    x_mm: x.slice(), y_mm: y.slice(),
    anterior: {curvature_D: g((xx, yy) => 46 + .3 * xx + .1 * yy), curvature_type: 'axial',
      elevation_um: g((xx, yy) => 17 + 2 * xx - yy),
      elevation_reference: {type: 'best_fit_sphere', fit_diameter_mm: 8}},
    posterior: {curvature_D: g((xx, yy) => -6 - .1 * yy), curvature_type: 'axial',
      elevation_um: g(xx => -5 + xx),
      elevation_reference: {type: 'best_fit_sphere', fit_diameter_mm: 8}},
    thickness_um: g((xx, yy) => 450 + 6 * xx + 3 * yy), thickness_definition: 'device_pachymetry'
  };
  if (!options.mapsOnly) {
    data.anterior.z_mm = g((xx, yy) => zSign * front(xx, yy));
    data.posterior.z_mm = g((xx, yy) => zSign * (front(xx, yy) - .65 - .003 * xx));
  }
  return data;
}

function imagePair(options = {}) {
  const diameter = options.diameter || 9, step = diameter / 60;
  const cells = fn => Array.from({length: 41}, (_, j) => Array.from({length: 41}, (_, i) => {
    if (Math.hypot(i - 20, j - 20) > 20) return null;
    const value = fn((i - 20) * step, (20 - j) * step);
    return {value, lo: value - 2.5, hi: value + 2.5};
  }));
  return {
    shape: {schema: 'nkpi-image-shape-1', source: 'report_elevation_estimate',
      reference: 'centered_untilted_float_bfs', bfs_radius_mm: 7.8, fit_diameter_mm: 8,
      diameter_mm: diameter, extent: 2 / 3, elevation_um: cells(options.elevation || (() => 100)), legend_step_um: 5},
    thickness: {schema: 'nkpi-report-image-map-1', id: 'thickness', unit: 'µm', map_type: 'pachymetry',
      source: 'report_color_estimate', diameter_mm: diameter, registration: 'printed_plot_circle', extent: 2 / 3,
      grid: cells(options.thickness || (() => 500))}
  };
}

test('Exact units, measured source, eye and visit are required before native geometry', () => {
  for (const [key, wrong] of [['xy', 'pixels'], ['z', 'um'], ['elevation', 'mm'], ['thickness', 'mm'], ['curvature', 'mm']]) {
    const raw = nativeFixture(); raw.units[key] = wrong;
    assert.throws(() => Shape.nativeModel(raw, 'OS', 'latest'), /units/i);
  }
  const raw = nativeFixture();
  assert.throws(() => Shape.nativeModel(raw, 'OD', 'latest'), /matching/i);
  assert.throws(() => Shape.nativeModel(raw, 'OS', 'first'), /matching/i);
  raw.kind = 'synthetic'; raw.source = 'synthetic_fixture';
  assert.throws(() => Shape.nativeModel(raw, 'OS', 'latest'), /matching/i);
});

test('All 16 declared eye/axis conventions retain the correct anatomical location', () => {
  const horizontal = [
    {eye: 'OD', x_positive: 'temporal', direction: -1},
    {eye: 'OD', x_positive: 'nasal', direction: 1},
    {eye: 'OS', x_positive: 'temporal', direction: 1},
    {eye: 'OS', x_positive: 'nasal', direction: -1}
  ];
  for (const orientation of horizontal) for (const y_positive of ['superior', 'inferior']) for (const z_positive of ['anterior', 'posterior']) {
    const raw = nativeFixture({...orientation, y_positive, z_positive});
    const m = Shape.nativeModel(raw, raw.eye, 'latest'), k = 4 * raw.x_mm.length + 5, v = m.vertices[k];
    near(v.front[0], 2 * orientation.direction);
    near(v.front[1], y_positive === 'superior' ? 1 : -1);
    near(v.front[2], 1.9 - .065 * 5 + .023 * 2 + .011);
    near(v.back[2], v.front[2] - .656);
    near(v.thickness, 465);
    near(v.anterior, 46.7); near(v.posterior, -6.1);
  }
});

test('Presentation sampling preserves native front/back coordinates at every supported irregular-grid node', () => {
  const raw = nativeFixture({x: [-3, -1.6, -.8, 0, .4, 1.3, 3], y: [-3, -1.2, -.35, 0, .7, 2.1, 3]});
  const input = JSON.stringify(raw), m = Shape.nativeModel(raw, 'OS', 'latest'), source = JSON.stringify(m.vertices);
  const a = Shape.anatomicalMesh(m);
  for (const v of m.vertices.filter(Boolean)) {
    const p = a.sample(v.front[0], v.front[1]);
    for (let i = 0; i < 3; i++) { near(p.front[i], v.front[i]); near(p.back[i], v.back[i]); }
    for (const field of fields) near(p[field], v[field]);
  }
  assert.equal(JSON.stringify(raw), input); assert.equal(JSON.stringify(m.vertices), source);
});

test('Supplied pachymetry remains independent of vertical front/back separation', () => {
  const raw = nativeFixture(), m = Shape.nativeModel(raw, 'OS', 'latest');
  const v = m.vertices[3 * 7 + 3];
  near(v.thickness, 450); near((v.front[2] - v.back[2]) * 1000, 650);
  const p = Shape.anatomicalMesh(m).sample(0, 0);
  near(p.thickness, 450); near((p.front[2] - p.back[2]) * 1000, 650);
  delete raw.thickness_um; delete raw.thickness_definition;
  const noPachy = Shape.nativeModel(raw, 'OS', 'latest');
  assert.equal(noPachy.thicknessRange, null);
  assert.ok(noPachy.vertices.filter(Boolean).every(q => q.thickness === null));
  assert.ok(!noPachy.overlays.some(q => q.id === 'thickness'));
});

test('Native missing front cells stay absent from source inspection and presentation readouts', () => {
  const raw = nativeFixture(); raw.anterior.z_mm[3][3] = null;
  const m = Shape.nativeModel(raw, 'OS', 'latest'), a = Shape.anatomicalMesh(m);
  assert.equal(m.vertices[3 * 7 + 3], null); assert.equal(Inspect.sample(m, 0, 0), null);
  const p = a.sample(0, 0);
  assert.equal(p.sourceId, -1); assert.equal(p.provenance, 'filled'); assert.equal(p.mapSupported, false);
  for (const field of fields) assert.equal(p[field], null);
  assert.ok(p.front.every(Number.isFinite));
});

test('Native asymmetric axis bounds cannot be clamped into false source locations', () => {
  for (const options of [{x: [0, 1, 2, 3]}, {x: [0, 1, 2, 3], eye: 'OD'}, {y: [0, 1, 2, 3]}]) {
    const raw = nativeFixture(options), m = Shape.nativeModel(raw, raw.eye, 'latest');
    const p = Shape.anatomicalMesh(m).sample(options.y ? 0 : raw.eye === 'OD' ? 1 : -1, options.y ? -1 : 0);
    assert.equal(p.sourceId, -1); assert.notEqual(p.provenance, 'source'); assert.equal(p.mapSupported, false);
    for (const field of fields) { assert.equal(p[field], null); assert.equal(p.displayValues[field], null); }
  }
});

test('Native map-only exports retain numerical maps on reference geometry with their own frame', () => {
  const raw = nativeFixture({mapsOnly: true, eye: 'OD', x_positive: 'temporal', y_positive: 'inferior'});
  const original = JSON.stringify(raw);
  const m = Shape.fromReport({eye: 'OD', visit: 'latest', surface: raw, image_maps: []});
  assert.equal(m.kind, 'reference'); assert.equal(m.mapSource, 'native');
  for (const field of fields) assert.ok(m.overlays.some(q => q.id === field));
  const v = m.vertices[4 * 7 + 5];
  near(v.front[0], -2); near(v.front[1], -1); near(v.anterior, 46.7); near(v.thickness, 465);
  assert.equal(Inspect.sample(m, 0, 0), null);
  const p = Shape.anatomicalMesh(m).sample(-2, -1);
  assert.equal(p.provenance, 'reference'); assert.equal(p.mapSupported, true); assert.ok(p.sourceId >= 0);
  near(p.anterior, 46.7); near(p.thickness, 465); assert.equal(JSON.stringify(raw), original);
});

test('Map-only curvature/elevation changes never manufacture geometric cone height', () => {
  const first = nativeFixture({mapsOnly: true}), second = structuredClone(first);
  second.anterior.curvature_D = second.anterior.curvature_D.map(row => row.map(v => v === null ? null : v + 25));
  second.anterior.elevation_um = second.anterior.elevation_um.map(row => row.map(v => v === null ? null : v + 200));
  const a = Shape.nativeReferenceModel(first, 'OS', 'latest'), b = Shape.nativeReferenceModel(second, 'OS', 'latest');
  assert.deepEqual(a.vertices.map(v => v && v.front), b.vertices.map(v => v && v.front));
  assert.deepEqual(a.vertices.map(v => v && v.back), b.vertices.map(v => v && v.back));
  assert.notEqual(a.vertices[24].anterior, b.vertices[24].anterior);
  assert.equal(Shape.emphasizeElevation(a, 6), a);
});

test('Map-only source matching rejects another eye, visit or simulated fixture', () => {
  const raw = nativeFixture({mapsOnly: true});
  assert.throws(() => Shape.nativeReferenceModel(raw, 'OD', 'latest'), /matching/i);
  assert.throws(() => Shape.nativeReferenceModel(raw, 'OS', 'first'), /matching/i);
  raw.kind = 'synthetic'; raw.source = 'synthetic_fixture';
  assert.throws(() => Shape.nativeReferenceModel(raw, 'OS', 'latest'), /matching/i);
});

test('Reference surfaces without a supported map never become pickable patient measurements', () => {
  const empty = Shape.anatomicalMesh(Shape.referenceModel([]));
  for (const p of [empty.sample(0, 0), empty.sample(4, 0), empty.sample(empty.radius, 0)]) {
    assert.equal(p.sourceId, -1); assert.equal(p.mapSupported, false); assert.equal(p.provenance, 'reference');
    for (const field of fields) assert.equal(p[field], null);
  }
  const raw = nativeFixture({mapsOnly: true, x: [0, 1, 2, 3]});
  const a = Shape.anatomicalMesh(Shape.nativeReferenceModel(raw, 'OS', 'latest'));
  assert.equal(a.sample(-1, 0).sourceId, -1); assert.equal(a.sample(-1, 0).mapSupported, false);
});

test('Native map holes remain uncolored with no numerical readout or picking ID', () => {
  const raw = nativeFixture({mapsOnly: true});
  raw.thickness_um[3][3] = null;
  for (const layer of ['anterior', 'posterior']) for (const field of ['curvature_D', 'elevation_um']) raw[layer][field][3][3] = null;
  const m = Shape.nativeReferenceModel(raw, 'OS', 'latest'), p = Shape.anatomicalMesh(m).sample(0, 0);
  assert.equal(p.mapSupported, false); assert.equal(p.sourceId, -1);
  for (const field of fields) assert.equal(p[field], null);
  assert.equal(p.displayValues.anterior, null);
});

test('Image µm-to-mm height conversion and the central report aperture are exact', () => {
  for (const diameter of [6, 8, 9, 12]) {
    const {shape, thickness} = imagePair({diameter}), m = Shape.imageModel(shape, thickness);
    near(m.radius, diameter / 2 * shape.extent);
    near(m.radius * 2, diameter * 2 / 3);
    near(m.vertices[840].front[2], .1); near(m.vertices[840].back[2], -.4);
    assert.equal(m.mapSource, 'image');
    assert.ok(m.vertices.filter(Boolean).every(v => Math.hypot(v.front[0], v.front[1]) <= m.radius + 1e-9));
  }
});

test('Image normal offsets honor superior/inferior slope and supplied thickness in physical mm', () => {
  const {shape, thickness} = imagePair({elevation: (x, y) => 100 + 20 * x + 30 * y,
    thickness: (x, y) => 500 + 15 * x + 12 * y});
  const m = Shape.imageModel(shape, thickness);
  for (const index of [840, 24 * 41 + 26, 16 * 41 + 14]) {
    const v = m.vertices[index], [x, y, z] = v.front, sag = Math.sqrt(7.8 ** 2 - x * x - y * y);
    near(z, sag - 7.8 + (100 + 20 * x + 30 * y) / 1000);
    near(v.thickness, 500 + 15 * x + 12 * y);
    const normal = v.front.map((q, k) => (q - v.back[k]) / (v.thickness / 1000));
    near(Math.hypot(...normal), 1);
    near(normal[0] + normal[2] * (-x / sag + .020), 0);
    near(normal[1] + normal[2] * (-y / sag + .030), 0);
    near(distance(v.front, v.back), v.thickness / 1000);
  }
});

test('Readable image elevation remains geometry when all pachymetry is absent', () => {
  const {shape} = imagePair(), before = JSON.stringify(shape);
  const m = Shape.imageModel(shape), linked = Shape.fromReport({eye: 'OS', visit: 'latest', shape_estimate: shape, image_maps: []});
  for (const model of [m, linked]) {
    assert.equal(model.kind, 'estimated'); assert.equal(model.mapSource, 'image');
    near(model.vertices[840].front[2], .1);
    assert.equal(model.vertices[840].back, null); assert.equal(model.vertices[840].thickness, null);
    assert.equal(model.thicknessRange, null); assert.ok(!model.overlays.some(v => v.id === 'thickness'));
    const point = Inspect.sample(model, 0, 0);
    assert.equal(point.back, null); assert.equal(point.thickness, null);
  }
  assert.equal(JSON.stringify(shape), before);
});

test('A local pachymetry hole does not erase valid anterior data or invent a source inner boundary', () => {
  const {shape, thickness} = imagePair();
  const baseline = Shape.imageModel(shape, thickness);
  for (let j = 15; j <= 25; j++) for (let i = 15; i <= 25; i++) thickness.grid[j][i] = null;
  const m = Shape.imageModel(shape, thickness), p = m.vertices[840];
  assert.ok(p); assert.equal(p.back, null); assert.equal(p.thickness, null); near(p.front[2], .1);
  assert.deepEqual(m.vertices.map(v => v && v.front), baseline.vertices.map(v => v && v.front));
  near(m.coverage, baseline.coverage);
  const display = Shape.anatomicalMesh(m).sample(0, 0);
  near(display.front[2], p.front[2]); assert.equal(display.thickness, null);
  assert.ok(display.back.every(Number.isFinite));
  assert.equal(Inspect.sample(m, 0, 0).back, null);
});

test('Unknown image source height stays unavailable even if thickness is complete', () => {
  const {shape, thickness} = imagePair();
  for (let j = 15; j <= 25; j++) for (let i = 15; i <= 25; i++) shape.elevation_um[j][i] = null;
  const m = Shape.imageModel(shape, thickness), p = Shape.anatomicalMesh(m).sample(0, 0);
  assert.equal(m.vertices[840], null); assert.equal(p.sourceId, -1); assert.equal(p.mapSupported, false);
  assert.equal(p.elevation, null); assert.equal(p.thickness, null);
  assert.equal(Inspect.sample(m, 0, 0), null);
});

test('Mismatched image diameters still fail instead of silently aligning different frames', () => {
  const {shape, thickness} = imagePair(); thickness.diameter_mm = 8;
  assert.throws(() => Shape.imageModel(shape, thickness), /diameter/i);
  const fallback = Shape.fromReport({eye: 'OS', visit: 'latest', shape_estimate: shape, image_maps: [thickness]});
  assert.equal(fallback.kind, 'reference'); assert.match(fallback.referenceReason, /diameter/i);
});

test('Raw numerical heights stay unchanged under all display relief requests', () => {
  const m = Shape.nativeModel(nativeFixture(), 'OS', 'latest'), before = JSON.stringify(m.vertices);
  for (const factor of [1, 3, 6]) assert.equal(Shape.emphasizeElevation(m, factor), m);
  assert.equal(JSON.stringify(m.vertices), before);
});

test('Image relief preserves original data, normal thickness and map measurements', () => {
  const {shape, thickness} = imagePair({elevation: (x, y) => 75 + 15 * x + 12 * y});
  const m = Shape.imageModel(shape, thickness), before = JSON.stringify(m.vertices);
  const e = Shape.emphasizeElevation(m, 3);
  for (let i = 0; i < m.vertices.length; i++) {
    const a = m.vertices[i], b = e.vertices[i]; if (!a) { assert.equal(b, null); continue; }
    near(b.front[2] - a.front[2], 2 * a.elevation / 1000);
    near(distance(a.front, a.back), distance(b.front, b.back));
    near(a.thickness, b.thickness); near(a.elevation, b.elevation);
  }
  assert.equal(JSON.stringify(m.vertices), before);
});

test('Default projection applies one physical scale to all three spatial axes', () => {
  const m = Shape.nativeModel(nativeFixture(), 'OS', 'latest'), zero = [0, 0, m.centerZ];
  const state = {yaw: 0, pitch: 0, roll: 0, zoom: 1};
  const origin = Shape.project(m, zero, state), x = Shape.project(m, [1, 0, m.centerZ], state), y = Shape.project(m, [0, 1, m.centerZ], state);
  near(x[0] - origin[0], origin[1] - y[1]);
  const side = {...state, yaw: Math.PI / 2};
  const p = Shape.project(m, zero, side), z = Shape.project(m, [0, 0, m.centerZ + 1], side);
  near(z[0] - p[0], x[0] - origin[0]);
});

test('A malformed numerical field cannot be relabeled as a valid native map', () => {
  const raw = nativeFixture({mapsOnly: true}); raw.anterior.curvature_type = 'unknown';
  assert.throws(() => Schema.validate(raw));
  assert.throws(() => Shape.nativeReferenceModel(raw, 'OS', 'latest'));
});

const overlay = (m, id = 'anterior') => m.overlays.find(l => l.id === id);
function shiftedNative(amount = 10, type = 'axial', definition = null, mapsOnly = false) {
  const raw = nativeFixture({mapsOnly});
  raw.anterior.curvature_type = type;
  raw.anterior.curvature_D = raw.anterior.curvature_D.map(row => row.map(v => v === null ? null : v + amount));
  if (definition) raw.comparison = {alignment: 'verified_common_grid', registration_id: 'fixture-grid', map_definition_id: definition};
  return mapsOnly ? Shape.nativeReferenceModel(raw, 'OS', 'latest') : Shape.nativeModel(raw, 'OS', 'latest');
}

test('Compatible native curvature definitions share one range and keep their type label', () => {
  const a = shiftedNative(0, 'axial', 'axial-v1'), b = shiftedNative(10, 'axial', 'axial-v1');
  const input = JSON.stringify([a.vertices, b.vertices]);
  const expected = [overlay(a).min, overlay(b).max];
  Shape.sharedScales([a, b]);
  for (const m of [a, b]) {
    near(overlay(m).min, expected[0]); near(overlay(m).max, expected[1]);
    assert.equal(overlay(m).sharedScale, true); assert.equal(overlay(m).mapSource, 'native');
    assert.equal(overlay(m).definition.type, 'axial'); assert.equal(overlay(m).definition.definition_id, 'axial-v1');
    assert.match(overlay(m).label, /\(axial\)/);
  }
  assert.equal(JSON.stringify([a.vertices, b.vertices]), input);
});

test('Axial, tangential, mean, and different declared native definitions do not share curvature scales', () => {
  for (const type of ['tangential', 'mean']) {
    const a = shiftedNative(0, 'axial', 'definition-a'), b = shiftedNative(20, type, 'definition-a');
    const own = [overlay(a).max, overlay(b).min]; Shape.sharedScales([a, b]);
    assert.equal(overlay(a).sharedScale, false); assert.equal(overlay(b).sharedScale, false);
    near(overlay(a).max, own[0]); near(overlay(b).min, own[1]);
    assert.equal(overlay(a, 'posterior').sharedScale, true, 'Independent compatible posterior layer remains comparable');
  }
  const a = shiftedNative(0, 'axial', 'definition-a'), b = shiftedNative(20, 'axial', 'definition-b');
  Shape.sharedScales([a, b]); assert.equal(overlay(a).sharedScale, false); assert.equal(overlay(b).sharedScale, false);
});

test('Unspecified device curvature requires the same explicit map-definition key to share a scale', () => {
  const a = shiftedNative(0, 'device_reported'), b = shiftedNative(10, 'device_reported');
  Shape.sharedScales([a, b]); assert.equal(overlay(a).sharedScale, false); assert.equal(overlay(b).sharedScale, false);
  const c = shiftedNative(0, 'device_reported', 'device-definition'), d = shiftedNative(10, 'device_reported', 'device-definition');
  Shape.sharedScales([c, d]); assert.equal(overlay(c).sharedScale, true); near(overlay(c).max, overlay(d).max);
});

test('Native map-only views preserve map definitions and source provenance', () => {
  const a = shiftedNative(0, 'tangential', 'native-map-v2', true), b = shiftedNative(10, 'tangential', 'native-map-v2', true);
  Shape.sharedScales([a, b]);
  assert.equal(a.kind, 'reference'); assert.equal(overlay(a).mapSource, 'native');
  assert.equal(overlay(a).definition.type, 'tangential'); assert.equal(overlay(a).sharedScale, true);
  assert.match(overlay(a).label, /tangential/);
});

function imageCurvature(value) {
  const {thickness} = imagePair();
  return {...thickness, id: 'anterior', unit: 'D', map_type: 'axial',
    grid: thickness.grid.map(row => row.map(v => v ? {value, lo: value - .5, hi: value + .5} : null))};
}

test('Image-derived and native curvature retain separate scales and provenance', () => {
  const native = shiftedNative(0), image = Shape.fromReport({image_maps: [imageCurvature(60)]});
  Shape.sharedScales([native, image]);
  assert.equal(overlay(native).definition.type, 'axial'); assert.equal(overlay(image).definition.type, 'axial');
  assert.equal(overlay(native).mapSource, 'native'); assert.equal(overlay(image).mapSource, 'image');
  assert.equal(overlay(native).sharedScale, false); assert.equal(overlay(image).sharedScale, false);
  near(overlay(image).min, 60); near(overlay(image).max, 60);
});

test('Regrouping scales discards a former partner range without changing source values', () => {
  const a = shiftedNative(0), b = shiftedNative(30), c = shiftedNative(100, 'mean');
  const own = [overlay(a).min, overlay(a).max];
  Shape.sharedScales([a, b]); assert.ok(overlay(a).max > own[1]);
  Shape.sharedScales([a, c]); assert.equal(overlay(a).sharedScale, false);
  near(overlay(a).min, own[0]); near(overlay(a).max, own[1]);
});

test('Display relief preserves a shared map scale through its cached presentation meshes', () => {
  const {shape} = imagePair();
  const a = Shape.fromReport({shape_estimate: shape, image_maps: [imageCurvature(45)]});
  const b = Shape.fromReport({shape_estimate: shape, image_maps: [imageCurvature(55)]});
  Shape.sharedScales([a, b]);
  const emphasized = Shape.emphasizeElevation(a, 3);
  for (const m of [a, emphasized, Shape.anatomicalMesh(emphasized), Shape.interactiveMesh(emphasized)]) {
    near(overlay(m).min, 45); near(overlay(m).max, 55); assert.equal(overlay(m).sharedScale, true);
  }
});

// Capture the actual software raster buffer before annotation text. This
// verifies the quantitative pixels independently of Canvas font rendering.
function bufferCanvas(width = 360, height = 360) {
  const canvas = {width, height, pixels: null};
  const gradient = {addColorStop() {}};
  const ctx = {
    createLinearGradient: () => gradient, createRadialGradient: () => gradient,
    fillRect() {}, beginPath() {}, moveTo() {}, lineTo() {}, closePath() {}, arc() {}, fill() {}, stroke() {},
    fillText() {}, setLineDash() {}, measureText: text => ({width: String(text).length * 6}),
    getImageData() {
      const data = new Uint8ClampedArray(width * height * 4);
      for (let i = 0; i < data.length; i += 4) { data[i] = 7; data[i + 1] = 16; data[i + 2] = 28; data[i + 3] = 255; }
      return {data, width, height};
    },
    putImageData(img) { canvas.pixels = img.data.slice(); }
  };
  canvas.getContext = () => ctx;
  return canvas;
}

test('Canvas fallback quantitative colors are opaque and unlit through camera rotation', () => {
  const raw = nativeFixture();
  raw.anterior.curvature_D = raw.anterior.curvature_D.map(row => row.map(v => v === null ? null : 50));
  const m = Shape.nativeModel(raw, 'OS', 'latest'); overlay(m).min = 40; overlay(m).max = 60;
  for (const camera of [{yaw: 0, pitch: 0}, {yaw: .6, pitch: -.25}]) {
    const canvas = bufferCanvas(), result = Shape.render(canvas, m, {...camera, color: 'anterior'});
    const indices = [];
    for (let i = 0; i < result.pick.length; i++) if (result.pick[i] === 24) indices.push(i);
    assert.ok(indices.length > 5, 'The selected central source area is visible');
    // Value 50 is the midpoint between palette stops [80,181,188] and [221,211,123].
    for (const i of indices) for (const [channel, expected] of [150.5, 196, 155.5].entries()) near(canvas.pixels[i * 4 + channel], expected, 1);
  }
});

test('Canvas fallback ignores modeled map colors and leaves geometry gaps unpickable', () => {
  const raw = nativeFixture(); raw.anterior.z_mm[3][3] = null;
  const m = Shape.nativeModel(raw, 'OS', 'latest'), a = Shape.anatomicalMesh(m);
  const first = bufferCanvas(), state = {yaw: 0, pitch: 0, color: 'anterior'};
  const one = Shape.render(first, m, state);
  for (const v of a.vertices) v.displayValues.anterior = 900;
  const second = bufferCanvas(), two = Shape.render(second, m, state);
  assert.deepEqual(second.pixels, first.pixels, 'Display-only harmonic fields never color a quantitative map');
  assert.deepEqual(two.pick, one.pick);
  const p = Shape.project(a, a.sample(0, 0).front, state, first.width, first.height);
  assert.equal(one.pick[Math.floor(p[1]) * first.width + Math.floor(p[0])], -1);
});
